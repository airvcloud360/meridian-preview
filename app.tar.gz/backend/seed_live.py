"""
Meridian ERP — first-run setup

Creates the company, the standard roles, and one administrator. Safe to run
again: if the administrator already exists, the password is reset rather
than a second account created, because two admin accounts nobody
remembers creating is how a system ends up with a forgotten back door.
"""

import os
import sys

import psycopg2
import psycopg2.extras

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import auth as A

DSN = os.environ["MERIDIAN_DSN"]
ADMIN_EMAIL = os.environ.get("MERIDIAN_ADMIN_EMAIL", "admin@meridian.local")
ADMIN_PASS = os.environ["MERIDIAN_ADMIN_PASS"]
COMPANY = os.environ.get("MERIDIAN_COMPANY", "Meridian")

psycopg2.extras.register_uuid()
conn = psycopg2.connect(DSN)
conn.autocommit = False
cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

cur.execute("SELECT id FROM tenants WHERE name = %s", [COMPANY])
row = cur.fetchone()
if row:
    tenant = row["id"]
    print(f"company '{COMPANY}' already exists")
else:
    cur.execute("INSERT INTO tenants (name) VALUES (%s) RETURNING id", [COMPANY])
    tenant = cur.fetchone()["id"]
    print(f"created company '{COMPANY}'")

cur.execute("SELECT app.seed_standard_roles(%s)", [tenant])
cur.execute("SELECT hr_seed_payroll_accounts(%s)", [tenant])
print("roles and payroll accounts ready")

# Row-level security is on, and it is not disabled for this script. The
# policies read app.tenant_id from the connection, so the seed declares
# which company it is acting for and is then held to it — the same rule
# every API request obeys. A seeder that turned RLS off would be the one
# place in the system where the main safety net does not apply.
cur.execute("SET LOCAL app.tenant_id = %s", [str(tenant)])

cur.execute("SELECT id FROM users WHERE lower(email) = %s", [ADMIN_EMAIL.lower()])
row = cur.fetchone()

if row:
    # Reset rather than duplicate. must_change_password is set again so a
    # reset always ends with the person choosing their own password.
    cur.execute(
        """UPDATE users
              SET password_hash = %s, must_change_password = true,
                  failed_attempts = 0, locked_until = NULL, is_active = true
            WHERE id = %s""",
        [A.hash_password(ADMIN_PASS), row["id"]])
    print(f"reset the password for {ADMIN_EMAIL}")
else:
    A.create_user(cur, tenant, ADMIN_EMAIL, "Administrator",
                  ADMIN_PASS, ["Administrator"])
    print(f"created administrator {ADMIN_EMAIL}")

# A directory with nobody in it looks broken rather than empty, so a first
# install gets a handful of people to look at. Skipped once real employees
# exist, so this never touches a live system.
cur.execute("SELECT COUNT(*) AS n FROM hr_employees WHERE tenant_id = %s", [tenant])
if cur.fetchone()["n"] == 0:
    depts = {}
    for d in ["Sales", "Finance", "Operations", "HR", "Logistics"]:
        cur.execute(
            "INSERT INTO hr_departments (tenant_id,name) VALUES (%s,%s) RETURNING id",
            [tenant, d])
        depts[d] = cur.fetchone()["id"]

    desigs = {}
    for g in ["Regional Sales Manager", "Finance Analyst", "Field Officer",
              "HR Executive", "Warehouse Supervisor"]:
        cur.execute(
            "INSERT INTO hr_designations (tenant_id,title) VALUES (%s,%s) RETURNING id",
            [tenant, g])
        desigs[g] = cur.fetchone()["id"]

    for name, paid in [("Earned", True), ("Sick", True),
                       ("Casual", True), ("Unpaid", False)]:
        cur.execute(
            "INSERT INTO hr_leave_types (tenant_id,name,is_paid) VALUES (%s,%s,%s)",
            [tenant, name, paid])

    sample = [
        ("EMP-0142", "Ananya Sharma", "Sales", "Regional Sales Manager",
         "2022-03-12", "active", 600000, 300000, 340000, 72000),
        ("EMP-0210", "Deepika Rao", "Finance", "Finance Analyst",
         "2021-01-19", "on_leave", 480000, 240000, 180000, 57600),
        ("EMP-0227", "Ramesh Yadav", "Operations", "Field Officer",
         "2024-09-02", "active", 240000, 120000, 90000, 28800),
        ("EMP-0240", "Priya Nair", "HR", "HR Executive",
         "2020-11-11", "notice_period", 420000, 210000, 150000, 50400),
        ("EMP-0255", "Arjun Verma", "Logistics", "Warehouse Supervisor",
         "2023-05-30", "active", 300000, 150000, 110000, 36000),
    ]
    for code, nm, dept, desig, doj, status, basic, hra, allow, pf in sample:
        cur.execute(
            """INSERT INTO hr_employees
                 (tenant_id, employee_code, full_name, department_id,
                  designation_id, date_of_joining, status)
               VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING id""",
            [tenant, code, nm, depts[dept], desigs[desig], doj, status])
        eid = cur.fetchone()["id"]
        cur.execute(
            """INSERT INTO hr_salary_structures
                 (tenant_id, employee_id, effective_from, basic, hra,
                  allowances, pf_employee, professional_tax)
               VALUES (%s,%s,%s,%s,%s,%s,%s,2400)""",
            [tenant, eid, doj, basic, hra, allow, pf])
    print(f"added {len(sample)} sample employees (delete them before going live)")
else:
    print("employees already exist, leaving them alone")

conn.commit()
print("setup complete")
