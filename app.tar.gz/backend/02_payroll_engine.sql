/* ==========================================================================
   Meridian ERP — payroll engine

   Two operations, deliberately separate:

     hr_compute_payroll()  works out what everyone is owed and writes
                           payslips. Safe to re-run — it clears and
                           recomputes, because a draft is not a record.

     hr_post_payroll()     writes the journal to the general ledger and
                           freezes the run. Not re-runnable. This is the
                           point of no return, and the schema enforces it.

   Splitting them means payroll can be computed, checked by a human, and
   corrected before any accounting entry exists. Computing and posting in
   one step is how you end up reversing journals every month.
   ========================================================================== */

/* --------------------------------------------------------------------------
   The salary structure in force on a given date.

   Payroll for March must use March's salary even if it is run in April
   after a raise. This function is why that works.
   -------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION hr_salary_on_date(
  p_employee_id uuid,
  p_on_date     date
) RETURNS hr_salary_structures
LANGUAGE sql STABLE AS $$
  SELECT *
    FROM hr_salary_structures
   WHERE employee_id = p_employee_id
     AND effective_from <= p_on_date
     AND (effective_to IS NULL OR effective_to > p_on_date)
   LIMIT 1
$$;

/* --------------------------------------------------------------------------
   Unpaid days in a month, from approved unpaid leave.

   Paid leave does not reduce pay, so only leave types with is_paid = false
   count here. Absent days recorded in attendance count too.
   -------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION hr_unpaid_days(
  p_employee_id uuid,
  p_year        integer,
  p_month       integer
) RETURNS numeric(5,1)
LANGUAGE sql STABLE AS $$
  WITH bounds AS (
    SELECT make_date(p_year, p_month, 1) AS first_day,
           (make_date(p_year, p_month, 1) + interval '1 month - 1 day')::date AS last_day
  ),
  unpaid_leave AS (
    SELECT COALESCE(SUM(
      -- Only the portion of the request that falls inside this month.
      (LEAST(lr.end_date, b.last_day) - GREATEST(lr.start_date, b.first_day) + 1)
    ), 0)::numeric AS days
      FROM hr_leave_requests lr
      JOIN hr_leave_types lt ON lt.id = lr.leave_type_id
      CROSS JOIN bounds b
     WHERE lr.employee_id = p_employee_id
       AND lr.status = 'approved'
       AND lt.is_paid = false
       AND lr.start_date <= b.last_day
       AND lr.end_date   >= b.first_day
  ),
  absences AS (
    SELECT COALESCE(SUM(CASE WHEN state = 'absent' THEN 1
                             WHEN state = 'half_day' THEN 0.5
                             ELSE 0 END), 0)::numeric AS days
      FROM hr_attendance a
      CROSS JOIN bounds b
     WHERE a.employee_id = p_employee_id
       AND a.work_date BETWEEN b.first_day AND b.last_day
  )
  SELECT (SELECT days FROM unpaid_leave) + (SELECT days FROM absences)
$$;

/* --------------------------------------------------------------------------
   Compute a payroll run.

   Clears any existing draft payslips and recomputes from scratch. Refuses
   to touch a run that has been approved or posted.
   -------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION hr_compute_payroll(p_run_id uuid)
RETURNS integer
LANGUAGE plpgsql AS $$
DECLARE
  v_run          hr_payroll_runs;
  v_emp          record;
  v_sal          hr_salary_structures;
  v_period_end   date;
  v_days_in_month numeric(4,1);
  v_unpaid       numeric(5,1);
  v_paid_days    numeric(5,1);
  v_ratio        numeric(10,6);
  v_basic        numeric(14,2);
  v_hra          numeric(14,2);
  v_allow        numeric(14,2);
  v_pf           numeric(14,2);
  v_ptax         numeric(14,2);
  v_gross        numeric(14,2);
  v_deduct       numeric(14,2);
  v_count        integer := 0;
BEGIN
  SELECT * INTO v_run FROM hr_payroll_runs WHERE id = p_run_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'No payroll run with id %', p_run_id;
  END IF;

  IF v_run.status IN ('approved', 'posted') THEN
    RAISE EXCEPTION
      'Payroll run is % and can no longer be recomputed.', v_run.status;
  END IF;

  v_period_end := (make_date(v_run.period_year, v_run.period_month, 1)
                   + interval '1 month - 1 day')::date;
  v_days_in_month := EXTRACT(DAY FROM v_period_end);

  DELETE FROM hr_payslips WHERE payroll_run_id = p_run_id;

  FOR v_emp IN
    SELECT e.id, e.employee_code, e.full_name
      FROM hr_employees e
     WHERE e.tenant_id = v_run.tenant_id
       AND e.status IN ('active', 'on_leave', 'notice_period')
       AND e.date_of_joining <= v_period_end
       AND (e.date_of_exit IS NULL OR e.date_of_exit >= make_date(v_run.period_year, v_run.period_month, 1))
     ORDER BY e.employee_code
  LOOP
    v_sal := hr_salary_on_date(v_emp.id, v_period_end);

    /* No salary structure means the record is incomplete. Skipping quietly
       would under-pay someone; better to stop and make it visible. */
    IF v_sal.id IS NULL THEN
      RAISE EXCEPTION
        'Employee % (%) has no salary structure effective %. '
        'Add one before running payroll.',
        v_emp.employee_code, v_emp.full_name, v_period_end;
    END IF;

    v_unpaid    := hr_unpaid_days(v_emp.id, v_run.period_year, v_run.period_month);
    v_paid_days := GREATEST(v_days_in_month - v_unpaid, 0);
    v_ratio     := v_paid_days / v_days_in_month;

    /* Annual figures to this month, pro-rated for unpaid days. */
    v_basic := ROUND((v_sal.basic      / 12) * v_ratio, 2);
    v_hra   := ROUND((v_sal.hra        / 12) * v_ratio, 2);
    v_allow := ROUND((v_sal.allowances / 12) * v_ratio, 2);

    /* PF and professional tax follow the same pro-rating. TDS is left at
       zero here: it depends on the employee's declared investments and
       regime choice, which is a separate piece of work. */
    v_pf    := ROUND((v_sal.pf_employee      / 12) * v_ratio, 2);
    v_ptax  := ROUND((v_sal.professional_tax / 12) * v_ratio, 2);

    v_gross  := v_basic + v_hra + v_allow;
    v_deduct := v_pf + v_ptax;

    INSERT INTO hr_payslips (
      tenant_id, payroll_run_id, employee_id, salary_structure_id,
      days_in_month, days_paid, days_unpaid,
      earned_basic, earned_hra, earned_allow,
      deduct_pf, deduct_ptax, deduct_tds, deduct_other,
      gross_pay, total_deduction, net_pay
    ) VALUES (
      v_run.tenant_id, p_run_id, v_emp.id, v_sal.id,
      v_days_in_month, v_paid_days, v_unpaid,
      v_basic, v_hra, v_allow,
      v_pf, v_ptax, 0, 0,
      v_gross, v_deduct, v_gross - v_deduct
    );

    v_count := v_count + 1;
  END LOOP;

  UPDATE hr_payroll_runs
     SET status = 'computed', computed_at = now()
   WHERE id = p_run_id;

  RETURN v_count;
END $$;

/* --------------------------------------------------------------------------
   Post a payroll run to the general ledger.

   The entry, in plain terms:

     Debit  Salaries expense        gross pay for everyone
     Credit PF payable              employee PF withheld
     Credit Professional tax payable
     Credit TDS payable
     Credit Salaries payable        what actually goes out to staff

   Debits equal credits by construction; post_event() refuses the entry if
   they ever do not.
   -------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION hr_post_payroll(
  p_run_id  uuid,
  p_user_id uuid DEFAULT NULL
) RETURNS uuid
LANGUAGE plpgsql AS $$
DECLARE
  v_run        hr_payroll_runs;
  v_gross      numeric(14,2);
  v_pf         numeric(14,2);
  v_ptax       numeric(14,2);
  v_tds        numeric(14,2);
  v_other      numeric(14,2);
  v_net        numeric(14,2);
  v_period_end date;
  v_lines      jsonb := '[]'::jsonb;
  v_journal_id uuid;
BEGIN
  SELECT * INTO v_run FROM hr_payroll_runs WHERE id = p_run_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'No payroll run with id %', p_run_id;
  END IF;

  IF v_run.status = 'posted' THEN
    RAISE EXCEPTION 'Payroll run is already posted (journal %).', v_run.journal_id;
  END IF;

  IF v_run.status <> 'approved' THEN
    RAISE EXCEPTION
      'Payroll run must be approved before posting. Current status: %.',
      v_run.status;
  END IF;

  SELECT SUM(gross_pay), SUM(deduct_pf), SUM(deduct_ptax),
         SUM(deduct_tds), SUM(deduct_other), SUM(net_pay)
    INTO v_gross, v_pf, v_ptax, v_tds, v_other, v_net
    FROM hr_payslips WHERE payroll_run_id = p_run_id;

  IF v_gross IS NULL OR v_gross = 0 THEN
    RAISE EXCEPTION 'Nothing to post: this run has no payslips.';
  END IF;

  v_period_end := (make_date(v_run.period_year, v_run.period_month, 1)
                   + interval '1 month - 1 day')::date;

  v_lines := v_lines || jsonb_build_object(
    'account_code', '5100', 'debit', v_gross, 'credit', 0);

  IF v_pf > 0 THEN
    v_lines := v_lines || jsonb_build_object(
      'account_code', '2210', 'debit', 0, 'credit', v_pf);
  END IF;
  IF v_ptax > 0 THEN
    v_lines := v_lines || jsonb_build_object(
      'account_code', '2220', 'debit', 0, 'credit', v_ptax);
  END IF;
  IF v_tds > 0 THEN
    v_lines := v_lines || jsonb_build_object(
      'account_code', '2230', 'debit', 0, 'credit', v_tds);
  END IF;
  IF v_other > 0 THEN
    v_lines := v_lines || jsonb_build_object(
      'account_code', '2240', 'debit', 0, 'credit', v_other);
  END IF;

  v_lines := v_lines || jsonb_build_object(
    'account_code', '2200', 'debit', 0, 'credit', v_net);

  v_journal_id := app.post_event(
    v_run.tenant_id,
    v_period_end,
    format('Payroll %s-%s', v_run.period_year,
           lpad(v_run.period_month::text, 2, '0')),
    'hr_payroll_run',
    p_run_id,
    v_lines
  );

  UPDATE hr_payroll_runs
     SET status = 'posted', posted_at = now(), journal_id = v_journal_id
   WHERE id = p_run_id;

  RETURN v_journal_id;
END $$;

/* --------------------------------------------------------------------------
   Accounts payroll needs. Idempotent — safe to call on every deploy.
   -------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION hr_seed_payroll_accounts(p_tenant_id uuid)
RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO accounts (tenant_id, code, name, type) VALUES
    (p_tenant_id, '5100', 'Salaries and wages',        'expense'),
    (p_tenant_id, '2200', 'Salaries payable',          'liability'),
    (p_tenant_id, '2210', 'Provident fund payable',    'liability'),
    (p_tenant_id, '2220', 'Professional tax payable',  'liability'),
    (p_tenant_id, '2230', 'TDS payable',               'liability'),
    (p_tenant_id, '2240', 'Other payroll deductions',  'liability')
  ON CONFLICT (tenant_id, code) DO NOTHING;
END $$;
