/* ==========================================================================
   Meridian ERP — HR & Payroll

   The employee record is the master key for this module. Salary structures,
   leave balances, attendance and payslips all hang off it, so nothing here
   can exist before an employee does, and the foreign keys enforce that
   rather than trusting the application to remember.

   Three principles this schema is built on:

   1. Money is never stored as a float. Every amount is numeric(14,2).

   2. History is never overwritten. A salary revision inserts a new row and
      closes the old one; it does not UPDATE the old figure. "What was this
      person paid in March" must stay answerable after a raise in April.

   3. A posted payslip is immutable. Once payroll has run and the journal
      has hit the ledger, the payslip is a historical record. Corrections
      are made by a later adjustment, never by editing the past — the same
      rule the accounting modules already follow.
   ========================================================================== */

/* --------------------------------------------------------------------------
   1. Departments and designations

   Kept as tables rather than free text so the directory filter, the org
   chart and payroll cost-centre reporting all agree on the same list.
   -------------------------------------------------------------------------- */

CREATE TABLE hr_departments (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    uuid NOT NULL REFERENCES tenants(id),
  name         text NOT NULL,
  cost_centre  text,
  is_active    boolean NOT NULL DEFAULT true,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, name)
);

CREATE TABLE hr_designations (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id),
  title       text NOT NULL,
  grade       text,
  is_active   boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, title)
);

/* --------------------------------------------------------------------------
   2. Employees

   employee_code is what appears on screen (EMP-0142) and must be stable
   for the life of the record — payslips, statutory filings and bank
   mandates all quote it.

   manager_id is a self-reference. It is nullable because someone has to be
   at the top, and a cycle check on write prevents a reporting loop.
   -------------------------------------------------------------------------- */

CREATE TYPE hr_employment_status AS ENUM
  ('active', 'on_leave', 'notice_period', 'exited', 'suspended');

CREATE TYPE hr_employment_type AS ENUM
  ('full_time', 'part_time', 'contract', 'intern', 'consultant');

CREATE TABLE hr_employees (
  id                 uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id          uuid NOT NULL REFERENCES tenants(id),
  employee_code      text NOT NULL,

  -- Identity
  full_name          text NOT NULL,
  date_of_birth      date,
  gender             text,

  -- Contact. Email is unique per tenant because it doubles as the login.
  email              text,
  phone              text,
  address_line       text,
  city               text,
  state              text,
  postal_code        text,

  -- Employment
  department_id      uuid REFERENCES hr_departments(id),
  designation_id     uuid REFERENCES hr_designations(id),
  manager_id         uuid REFERENCES hr_employees(id),
  employment_type    hr_employment_type   NOT NULL DEFAULT 'full_time',
  status             hr_employment_status NOT NULL DEFAULT 'active',
  date_of_joining    date NOT NULL,
  date_of_exit       date,

  -- Statutory identifiers. Stored in full; the API masks them on read for
  -- anyone without explicit permission (see the note in 03_permissions).
  pan                text,
  aadhaar            text,
  uan                text,          -- provident fund universal account number
  esic_number        text,

  -- Payment
  bank_account_name  text,
  bank_account_no    text,
  bank_ifsc          text,

  -- The linked login, once the person is invited into the system.
  user_id            uuid REFERENCES users(id),

  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),

  UNIQUE (tenant_id, employee_code),

  -- An exit date is required for an exited employee and forbidden otherwise.
  CONSTRAINT exit_date_matches_status CHECK (
    (status = 'exited' AND date_of_exit IS NOT NULL) OR
    (status <> 'exited' AND date_of_exit IS NULL)
  ),
  CONSTRAINT exit_after_joining CHECK (
    date_of_exit IS NULL OR date_of_exit >= date_of_joining
  ),
  CONSTRAINT not_own_manager CHECK (manager_id IS DISTINCT FROM id)
);

CREATE UNIQUE INDEX hr_employees_email_key
  ON hr_employees (tenant_id, lower(email)) WHERE email IS NOT NULL;

CREATE INDEX hr_employees_department  ON hr_employees (tenant_id, department_id);
CREATE INDEX hr_employees_status      ON hr_employees (tenant_id, status);
CREATE INDEX hr_employees_manager     ON hr_employees (manager_id);

/* Full-text-ish search for the directory. Without this, searching a
   500-person directory does a sequential scan on every keystroke. */
CREATE INDEX hr_employees_name_search
  ON hr_employees USING gin (to_tsvector('simple', full_name));

/* --------------------------------------------------------------------------
   3. Salary structure

   Effective-dated. A raise closes the current row (sets effective_to) and
   inserts a new one. Nothing is ever overwritten, so payroll for a past
   month can always be recomputed from what was true at the time.

   The exclusion constraint makes overlapping periods impossible at the
   database level — application code cannot get this wrong.
   -------------------------------------------------------------------------- */

CREATE EXTENSION IF NOT EXISTS btree_gist;

CREATE TABLE hr_salary_structures (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id      uuid NOT NULL REFERENCES tenants(id),
  employee_id    uuid NOT NULL REFERENCES hr_employees(id) ON DELETE RESTRICT,

  effective_from date NOT NULL,
  effective_to   date,              -- NULL means "current"

  -- Annual figures, matching how CTC is discussed and offered in India.
  basic          numeric(14,2) NOT NULL CHECK (basic >= 0),
  hra            numeric(14,2) NOT NULL DEFAULT 0 CHECK (hra >= 0),
  allowances     numeric(14,2) NOT NULL DEFAULT 0 CHECK (allowances >= 0),

  -- Deductions
  pf_employee    numeric(14,2) NOT NULL DEFAULT 0 CHECK (pf_employee >= 0),
  pf_employer    numeric(14,2) NOT NULL DEFAULT 0 CHECK (pf_employer >= 0),
  professional_tax numeric(14,2) NOT NULL DEFAULT 0 CHECK (professional_tax >= 0),

  notes          text,
  created_by     uuid REFERENCES users(id),
  created_at     timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT salary_period_valid CHECK (
    effective_to IS NULL OR effective_to > effective_from
  ),

  /* No employee can have two salary structures covering the same day. */
  CONSTRAINT no_overlapping_salary EXCLUDE USING gist (
    employee_id WITH =,
    daterange(effective_from, effective_to, '[)') WITH &&
  )
);

CREATE INDEX hr_salary_current
  ON hr_salary_structures (employee_id) WHERE effective_to IS NULL;

/* Gross and net are derived, never stored — a stored total is a second
   source of truth waiting to disagree with its own components. */
CREATE OR REPLACE FUNCTION hr_gross_annual(p_structure hr_salary_structures)
RETURNS numeric(14,2) LANGUAGE sql IMMUTABLE AS $$
  SELECT p_structure.basic + p_structure.hra + p_structure.allowances
$$;

CREATE OR REPLACE FUNCTION hr_net_annual(p_structure hr_salary_structures)
RETURNS numeric(14,2) LANGUAGE sql IMMUTABLE AS $$
  SELECT p_structure.basic + p_structure.hra + p_structure.allowances
       - p_structure.pf_employee - p_structure.professional_tax
$$;

/* --------------------------------------------------------------------------
   4. Leave

   Entitlement is granted per employee per leave type per year. Balance is
   derived from entitlement minus approved days — never stored as a running
   figure, because a stored balance drifts the first time a request is
   cancelled or backdated.
   -------------------------------------------------------------------------- */

CREATE TABLE hr_leave_types (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id      uuid NOT NULL REFERENCES tenants(id),
  name           text NOT NULL,          -- Earned, Sick, Casual, Unpaid
  is_paid        boolean NOT NULL DEFAULT true,
  carries_over   boolean NOT NULL DEFAULT false,
  max_carry_over numeric(5,1),
  is_active      boolean NOT NULL DEFAULT true,
  UNIQUE (tenant_id, name)
);

CREATE TABLE hr_leave_entitlements (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id),
  employee_id   uuid NOT NULL REFERENCES hr_employees(id) ON DELETE CASCADE,
  leave_type_id uuid NOT NULL REFERENCES hr_leave_types(id),
  year          integer NOT NULL,
  days_granted  numeric(5,1) NOT NULL CHECK (days_granted >= 0),
  created_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id, leave_type_id, year)
);

CREATE TYPE hr_leave_status AS ENUM
  ('draft', 'pending', 'approved', 'rejected', 'cancelled');

CREATE TABLE hr_leave_requests (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id      uuid NOT NULL REFERENCES tenants(id),
  employee_id    uuid NOT NULL REFERENCES hr_employees(id) ON DELETE RESTRICT,
  leave_type_id  uuid NOT NULL REFERENCES hr_leave_types(id),

  start_date     date NOT NULL,
  end_date       date NOT NULL,
  days           numeric(5,1) NOT NULL CHECK (days > 0),
  reason         text,

  status         hr_leave_status NOT NULL DEFAULT 'pending',
  approver_id    uuid REFERENCES hr_employees(id),
  decided_at     timestamptz,
  decision_note  text,

  created_at     timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT leave_dates_ordered CHECK (end_date >= start_date),

  /* A decision requires a decider, and vice versa. */
  CONSTRAINT decision_complete CHECK (
    (status IN ('approved','rejected') AND approver_id IS NOT NULL AND decided_at IS NOT NULL)
    OR status NOT IN ('approved','rejected')
  ),

  /* Nobody approves their own leave. */
  CONSTRAINT no_self_approval CHECK (approver_id IS DISTINCT FROM employee_id)
);

CREATE INDEX hr_leave_requests_employee ON hr_leave_requests (employee_id, start_date);
CREATE INDEX hr_leave_requests_pending
  ON hr_leave_requests (tenant_id, approver_id) WHERE status = 'pending';

/* Approved leave cannot overlap for the same person. Pending requests may
   overlap — that is a conflict for a human to resolve, not a hard error. */
CREATE UNIQUE INDEX hr_leave_no_overlap_marker
  ON hr_leave_requests (id) WHERE status = 'approved';

ALTER TABLE hr_leave_requests
  ADD CONSTRAINT no_overlapping_approved_leave EXCLUDE USING gist (
    employee_id WITH =,
    daterange(start_date, end_date, '[]') WITH &&
  ) WHERE (status = 'approved');

/* Balance, derived. */
CREATE OR REPLACE FUNCTION hr_leave_balance(
  p_employee_id   uuid,
  p_leave_type_id uuid,
  p_year          integer
) RETURNS numeric(5,1)
LANGUAGE sql STABLE AS $$
  SELECT COALESCE(
    (SELECT days_granted FROM hr_leave_entitlements
      WHERE employee_id = p_employee_id
        AND leave_type_id = p_leave_type_id
        AND year = p_year), 0)
  -
  COALESCE(
    (SELECT SUM(days) FROM hr_leave_requests
      WHERE employee_id = p_employee_id
        AND leave_type_id = p_leave_type_id
        AND status = 'approved'
        AND EXTRACT(YEAR FROM start_date) = p_year), 0)
$$;

/* --------------------------------------------------------------------------
   5. Attendance
   -------------------------------------------------------------------------- */

CREATE TYPE hr_attendance_state AS ENUM
  ('present', 'absent', 'half_day', 'on_leave', 'holiday', 'weekly_off');

CREATE TABLE hr_attendance (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    uuid NOT NULL REFERENCES tenants(id),
  employee_id  uuid NOT NULL REFERENCES hr_employees(id) ON DELETE CASCADE,
  work_date    date NOT NULL,
  state        hr_attendance_state NOT NULL,
  hours_worked numeric(4,1) CHECK (hours_worked IS NULL OR hours_worked BETWEEN 0 AND 24),
  note         text,
  recorded_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (employee_id, work_date)
);

CREATE INDEX hr_attendance_month ON hr_attendance (tenant_id, work_date);

/* --------------------------------------------------------------------------
   6. Payroll runs and payslips

   A payroll run is the unit of work: one tenant, one month, computed once,
   posted once. The unique index makes a duplicate run for the same month
   impossible rather than merely discouraged.
   -------------------------------------------------------------------------- */

CREATE TYPE hr_payroll_status AS ENUM
  ('draft', 'computed', 'approved', 'posted', 'cancelled');

CREATE TABLE hr_payroll_runs (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid NOT NULL REFERENCES tenants(id),
  period_month  integer NOT NULL CHECK (period_month BETWEEN 1 AND 12),
  period_year   integer NOT NULL CHECK (period_year BETWEEN 2000 AND 2100),
  status        hr_payroll_status NOT NULL DEFAULT 'draft',

  computed_at   timestamptz,
  approved_at   timestamptz,
  approved_by   uuid REFERENCES users(id),
  posted_at     timestamptz,
  journal_id    uuid REFERENCES journals(id),

  created_by    uuid REFERENCES users(id),
  created_at    timestamptz NOT NULL DEFAULT now(),

  /* One live run per month. A cancelled run does not block a re-run. */
  CONSTRAINT posted_run_has_journal CHECK (
    (status = 'posted' AND journal_id IS NOT NULL AND posted_at IS NOT NULL)
    OR status <> 'posted'
  )
);

CREATE UNIQUE INDEX hr_payroll_one_live_run_per_month
  ON hr_payroll_runs (tenant_id, period_year, period_month)
  WHERE status <> 'cancelled';

CREATE TABLE hr_payslips (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenants(id),
  payroll_run_id  uuid NOT NULL REFERENCES hr_payroll_runs(id) ON DELETE CASCADE,
  employee_id     uuid NOT NULL REFERENCES hr_employees(id) ON DELETE RESTRICT,

  /* The salary structure this payslip was computed from. Keeping the link
     means a payslip can always be explained, even after later revisions. */
  salary_structure_id uuid NOT NULL REFERENCES hr_salary_structures(id),

  days_in_month   numeric(4,1) NOT NULL CHECK (days_in_month > 0),
  days_paid       numeric(4,1) NOT NULL CHECK (days_paid >= 0),
  days_unpaid     numeric(4,1) NOT NULL DEFAULT 0 CHECK (days_unpaid >= 0),

  -- Monthly figures as actually paid.
  earned_basic    numeric(14,2) NOT NULL CHECK (earned_basic     >= 0),
  earned_hra      numeric(14,2) NOT NULL DEFAULT 0 CHECK (earned_hra >= 0),
  earned_allow    numeric(14,2) NOT NULL DEFAULT 0 CHECK (earned_allow >= 0),

  deduct_pf       numeric(14,2) NOT NULL DEFAULT 0 CHECK (deduct_pf   >= 0),
  deduct_ptax     numeric(14,2) NOT NULL DEFAULT 0 CHECK (deduct_ptax >= 0),
  deduct_tds      numeric(14,2) NOT NULL DEFAULT 0 CHECK (deduct_tds  >= 0),
  deduct_other    numeric(14,2) NOT NULL DEFAULT 0 CHECK (deduct_other>= 0),

  gross_pay       numeric(14,2) NOT NULL,
  total_deduction numeric(14,2) NOT NULL,
  net_pay         numeric(14,2) NOT NULL,

  created_at      timestamptz NOT NULL DEFAULT now(),

  UNIQUE (payroll_run_id, employee_id),

  CONSTRAINT days_add_up CHECK (days_paid + days_unpaid <= days_in_month),

  /* The arithmetic is checked by the database, not trusted to the caller.
     If a future change to the payroll code produces an inconsistent slip,
     the insert fails rather than quietly paying the wrong amount. */
  CONSTRAINT gross_is_sum_of_earnings CHECK (
    gross_pay = earned_basic + earned_hra + earned_allow
  ),
  CONSTRAINT deductions_add_up CHECK (
    total_deduction = deduct_pf + deduct_ptax + deduct_tds + deduct_other
  ),
  CONSTRAINT net_is_gross_less_deductions CHECK (
    net_pay = gross_pay - total_deduction
  ),
  CONSTRAINT net_pay_not_negative CHECK (net_pay >= 0)
);

CREATE INDEX hr_payslips_employee ON hr_payslips (employee_id);
CREATE INDEX hr_payslips_run      ON hr_payslips (payroll_run_id);

/* --------------------------------------------------------------------------
   7. Immutability of posted payroll

   Once a run is posted, its payslips are history. This is enforced by a
   trigger rather than by convention, because "we agreed not to edit those"
   is not a control.
   -------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION hr_block_posted_payslip_change()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  v_status hr_payroll_status;
BEGIN
  SELECT status INTO v_status
    FROM hr_payroll_runs
   WHERE id = COALESCE(NEW.payroll_run_id, OLD.payroll_run_id);

  IF v_status = 'posted' THEN
    RAISE EXCEPTION
      'Payslip belongs to a posted payroll run and cannot be changed. '
      'Post a correcting adjustment in a later run instead.';
  END IF;

  RETURN COALESCE(NEW, OLD);
END $$;

CREATE TRIGGER hr_payslips_immutable_once_posted
  BEFORE UPDATE OR DELETE ON hr_payslips
  FOR EACH ROW EXECUTE FUNCTION hr_block_posted_payslip_change();

/* A posted run may only move to cancelled, and only if reversed upstream. */
CREATE OR REPLACE FUNCTION hr_guard_payroll_status()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.status = 'posted' AND NEW.status <> 'posted' THEN
    RAISE EXCEPTION 'A posted payroll run cannot be reopened.';
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER hr_payroll_runs_status_guard
  BEFORE UPDATE ON hr_payroll_runs
  FOR EACH ROW EXECUTE FUNCTION hr_guard_payroll_status();

/* Register the append-only tables so the platform's RLS reconciler keeps
   them that way. Listing them here rather than hard-coding names in the
   reconciler is what lets a second append-only table inherit the rule. */
INSERT INTO app.append_only_tables (table_name)
VALUES ('hr_payslips')
ON CONFLICT DO NOTHING;

/* --------------------------------------------------------------------------
   8. Reporting-line cycle check

   A reports-to loop makes approvals and org charts hang. Cheaper to refuse
   the write than to detect the cycle later.
   -------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION hr_check_manager_cycle()
RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE
  v_current uuid := NEW.manager_id;
  v_hops    integer := 0;
BEGIN
  WHILE v_current IS NOT NULL LOOP
    IF v_current = NEW.id THEN
      RAISE EXCEPTION 'Reporting line would form a loop.';
    END IF;
    v_hops := v_hops + 1;
    IF v_hops > 64 THEN
      RAISE EXCEPTION 'Reporting line is implausibly deep; refusing.';
    END IF;
    SELECT manager_id INTO v_current FROM hr_employees WHERE id = v_current;
  END LOOP;
  RETURN NEW;
END $$;

CREATE TRIGGER hr_employees_manager_cycle
  BEFORE INSERT OR UPDATE OF manager_id ON hr_employees
  FOR EACH ROW WHEN (NEW.manager_id IS NOT NULL)
  EXECUTE FUNCTION hr_check_manager_cycle();

/* Keep updated_at honest. */
CREATE OR REPLACE FUNCTION hr_touch_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at := now();
  RETURN NEW;
END $$;

CREATE TRIGGER hr_employees_touch
  BEFORE UPDATE ON hr_employees
  FOR EACH ROW EXECUTE FUNCTION hr_touch_updated_at();
