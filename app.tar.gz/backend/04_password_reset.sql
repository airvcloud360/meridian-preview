/* ==========================================================================
   Meridian ERP — password reset

   Three ways back in, deliberately, because each covers a case the others
   cannot:

     1. An administrator resets an employee's password. Works today, no
        email server needed. This is how most resets in a small company
        actually happen: someone walks over and asks.

     2. Self-service by email link. Needs an email server configured. The
        token machinery is here and tested; only delivery is pending.

     3. A rescue command run on the server itself, for when the last
        administrator is locked out. Physical access to the machine is
        the final authority — there is nothing above it to appeal to.

   The tokens follow the same rule as session tokens: stored hashed, so a
   dump of this table cannot be used to take over an account.
   ========================================================================== */

CREATE TABLE IF NOT EXISTS password_resets (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,

  token_hash  text NOT NULL UNIQUE,

  /* Short-lived on purpose. A reset link that works for a week is a
     standing key sitting in an inbox. One hour is enough for someone to
     read the mail and act on it. */
  expires_at  timestamptz NOT NULL,

  /* Single use. Once redeemed the row stays, so a second attempt with the
     same link is refused rather than silently working again. */
  used_at     timestamptz,

  /* Who asked, from where. A burst of requests for one account is worth
     seeing. */
  requested_ip inet,
  issued_by    uuid REFERENCES users(id),   -- NULL when self-requested

  created_at  timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT reset_expiry_sane CHECK (expires_at > created_at)
);

CREATE INDEX IF NOT EXISTS password_resets_live
  ON password_resets (token_hash) WHERE used_at IS NULL;
CREATE INDEX IF NOT EXISTS password_resets_user
  ON password_resets (user_id, created_at DESC);

/* Housekeeping. A spent or expired token has no value, and keeping them
   forever only grows the table an attacker would want. */
CREATE OR REPLACE FUNCTION app.purge_expired_resets()
RETURNS integer LANGUAGE plpgsql AS $$
DECLARE v_count integer;
BEGIN
  DELETE FROM password_resets
   WHERE expires_at < now() - interval '2 days'
      OR (used_at IS NOT NULL AND used_at < now() - interval '2 days');
  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END $$;

/* Rate limit, enforced in the database rather than in the API so it holds
   however the request arrives. Three live requests per account is enough
   for someone who clicked twice and lost the first mail. */
CREATE OR REPLACE FUNCTION app.reset_requests_recently(p_user_id uuid)
RETURNS integer LANGUAGE sql STABLE AS $$
  SELECT COUNT(*)::integer FROM password_resets
   WHERE user_id = p_user_id
     AND used_at IS NULL
     AND created_at > now() - interval '15 minutes'
$$;
