/* ==========================================================================
   Meridian ERP — authentication and permissions

   Nothing in this file trusts the application. The rules a security layer
   depends on live in the database, because an API is one bug away from
   forgetting to check something and a constraint is not.

   Four decisions worth understanding before changing anything here:

   1. PASSWORDS ARE NEVER STORED. Only a bcrypt hash, and the column is
      named so that nobody mistakes it for something reversible. There is
      no code path anywhere that can recover a password.

   2. SESSION TOKENS ARE STORED HASHED, exactly like passwords. If this
      database is ever dumped, the attacker gets a table of useless
      hashes rather than a set of live sessions they can replay.

      This is why sessions are opaque tokens rather than JWTs. A JWT
      cannot be revoked without keeping a blocklist, which is a session
      table with extra steps. For a system holding payroll, being able
      to kill a session instantly matters more than saving a lookup.

   3. PERMISSIONS ARE CHECKED IN SQL, not in Python. app.has_permission()
      is used by both the API and the row-level security policies, so a
      forgotten check in a route handler still cannot leak another
      tenant's data.

   4. THE AUDIT LOG IS APPEND-ONLY, enforced by trigger. A log an
      administrator can quietly edit is not evidence of anything.
   ========================================================================== */

/* --------------------------------------------------------------------------
   1. Users

   A user is a login. An employee is a person on the payroll. They are
   different things: contractors and auditors get logins without being
   employees, and an employee may never log in at all. hr_employees.user_id
   links them when both exist.
   -------------------------------------------------------------------------- */

ALTER TABLE users ADD COLUMN IF NOT EXISTS tenant_id uuid REFERENCES tenants(id);
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_hash text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_active boolean NOT NULL DEFAULT true;

/* Repeated failures lock the account for a while. Without this, a weak
   password is a matter of time rather than a matter of luck. */
ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_attempts integer NOT NULL DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until timestamptz;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login_at timestamptz;
ALTER TABLE users ADD COLUMN IF NOT EXISTS password_changed_at timestamptz;
ALTER TABLE users ADD COLUMN IF NOT EXISTS must_change_password boolean NOT NULL DEFAULT false;

CREATE UNIQUE INDEX IF NOT EXISTS users_email_lower ON users (lower(email));

/* --------------------------------------------------------------------------
   2. Roles and permissions

   Permissions are strings like 'employee.read' or 'salary.write'. Roles
   bundle them. A user holds roles, never bare permissions — otherwise
   nobody can answer "what can this person do" without reading a list.

   The permission list is a table rather than an enum so a new module can
   add its own without a migration to the type.
   -------------------------------------------------------------------------- */

CREATE TABLE IF NOT EXISTS permissions (
  code        text PRIMARY KEY,
  module      text NOT NULL,
  description text NOT NULL
);

INSERT INTO permissions (code, module, description) VALUES
  ('employee.read',      'hr', 'View employee records'),
  ('employee.write',     'hr', 'Create and edit employee records'),
  ('employee.id.reveal', 'hr', 'See full PAN, Aadhaar and bank numbers'),
  ('salary.read',        'hr', 'View salary structures'),
  ('salary.write',       'hr', 'Set and revise salary'),
  ('leave.read',         'hr', 'View leave records'),
  ('leave.approve',      'hr', 'Approve or reject leave'),
  ('payroll.read',       'hr', 'View payroll runs, payslips and registers'),
  ('payroll.run',        'hr', 'Create and compute payroll'),
  ('payroll.approve',    'hr', 'Approve a computed payroll run'),
  ('payroll.post',       'hr', 'Post payroll to the general ledger'),
  ('user.manage',        'admin', 'Create users and assign roles'),
  ('audit.read',         'admin', 'Read the audit log')
ON CONFLICT (code) DO NOTHING;

CREATE TABLE IF NOT EXISTS roles (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id),
  name        text NOT NULL,
  description text,
  is_system   boolean NOT NULL DEFAULT false,
  created_at  timestamptz NOT NULL DEFAULT now(),
  UNIQUE (tenant_id, name)
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id         uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_code text NOT NULL REFERENCES permissions(code),
  PRIMARY KEY (role_id, permission_code)
);

CREATE TABLE IF NOT EXISTS user_roles (
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id     uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  granted_at  timestamptz NOT NULL DEFAULT now(),
  granted_by  uuid REFERENCES users(id),
  PRIMARY KEY (user_id, role_id)
);

/* --------------------------------------------------------------------------
   3. Sessions

   token_hash, not token. The plain token exists only in the response to
   the login call and in the client's memory. It is never written down
   here, so a database dump yields nothing replayable.
   -------------------------------------------------------------------------- */

CREATE TABLE IF NOT EXISTS sessions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tenant_id     uuid NOT NULL REFERENCES tenants(id),
  token_hash    text NOT NULL UNIQUE,
  issued_at     timestamptz NOT NULL DEFAULT now(),
  expires_at    timestamptz NOT NULL,
  last_seen_at  timestamptz NOT NULL DEFAULT now(),
  revoked_at    timestamptz,
  ip            text,
  user_agent    text,
  CONSTRAINT session_expiry_sane CHECK (expires_at > issued_at)
);

CREATE INDEX IF NOT EXISTS sessions_user ON sessions (user_id) WHERE revoked_at IS NULL;
CREATE INDEX IF NOT EXISTS sessions_expiry ON sessions (expires_at) WHERE revoked_at IS NULL;

/* --------------------------------------------------------------------------
   4. Audit log

   Append-only. Every sensitive read and every write that matters lands
   here, and nothing can amend it afterwards — not an administrator, not
   the application, not a migration that forgot.
   -------------------------------------------------------------------------- */

CREATE TABLE IF NOT EXISTS audit_log (
  id          bigserial PRIMARY KEY,
  tenant_id   uuid REFERENCES tenants(id),
  user_id     uuid REFERENCES users(id),
  at          timestamptz NOT NULL DEFAULT now(),
  action      text NOT NULL,          -- 'login.success', 'salary.revise'
  object_type text,                   -- 'employee', 'payroll_run'
  object_id   uuid,
  detail      jsonb,
  ip          text
);

CREATE INDEX IF NOT EXISTS audit_log_tenant_time ON audit_log (tenant_id, at DESC);
CREATE INDEX IF NOT EXISTS audit_log_object ON audit_log (object_type, object_id);

CREATE OR REPLACE FUNCTION app_block_audit_change()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION
    'The audit log is append only. Entries cannot be changed or removed.';
END $$;

DROP TRIGGER IF EXISTS audit_log_append_only ON audit_log;
CREATE TRIGGER audit_log_append_only
  BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION app_block_audit_change();

INSERT INTO app.append_only_tables (table_name)
VALUES ('audit_log') ON CONFLICT DO NOTHING;

/* --------------------------------------------------------------------------
   5. The permission check

   One function, used by the API and by row-level security. A route that
   forgets to call it is still stopped by the policies below.
   -------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION app.has_permission(p_user_id uuid, p_code text)
RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1
      FROM user_roles ur
      JOIN role_permissions rp ON rp.role_id = ur.role_id
      JOIN users u ON u.id = ur.user_id
     WHERE ur.user_id = p_user_id
       AND rp.permission_code = p_code
       AND u.is_active
  )
$$;

/* Convenience for the current session, set by the API on each connection. */
CREATE OR REPLACE FUNCTION app.can(p_code text)
RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT app.has_permission(app.current_user_id(), p_code)
$$;

CREATE OR REPLACE FUNCTION app.require(p_code text)
RETURNS void
LANGUAGE plpgsql STABLE AS $$
BEGIN
  IF NOT app.can(p_code) THEN
    RAISE EXCEPTION 'permission denied: %', p_code
      USING ERRCODE = 'insufficient_privilege';
  END IF;
END $$;

/* --------------------------------------------------------------------------
   6. Row-level security

   The backstop. Even if a route forgets its tenant filter, a query cannot
   return another company's rows.

   Note the FORCE: without it the table owner bypasses its own policies,
   which is exactly the account the application connects as.
   -------------------------------------------------------------------------- */

DO $$
DECLARE t text;
BEGIN
  FOREACH t IN ARRAY ARRAY[
    'hr_employees', 'hr_departments', 'hr_designations',
    'hr_salary_structures', 'hr_leave_types', 'hr_leave_entitlements',
    'hr_leave_requests', 'hr_attendance', 'hr_payroll_runs', 'hr_payslips'
  ] LOOP
    EXECUTE format('ALTER TABLE %I ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE %I FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('DROP POLICY IF EXISTS tenant_isolation ON %I', t);
    EXECUTE format($p$
      CREATE POLICY tenant_isolation ON %I
        USING (tenant_id = app.current_tenant())
        WITH CHECK (tenant_id = app.current_tenant())
    $p$, t);
  END LOOP;
END $$;

/* Salary is the most sensitive table in the module, so it carries a second
   policy: the right tenant is not enough, the session also needs the
   permission. Two independent conditions, either of which stops a leak. */
DROP POLICY IF EXISTS salary_needs_permission ON hr_salary_structures;
CREATE POLICY salary_needs_permission ON hr_salary_structures
  FOR SELECT
  USING (tenant_id = app.current_tenant() AND app.can('salary.read'));

/* --------------------------------------------------------------------------
   7. Standard roles

   Created per tenant. Payroll is split three ways on purpose:

     payroll.run      compute the figures        HR
     payroll.approve  sign the figures off       Finance
     payroll.post     commit them to the ledger  Finance

   The control that matters is that whoever computes the numbers cannot
   also release the money. An earlier version gave HR both run and
   approve, which meant one person could prepare a payroll and wave it
   through unchecked — the approval step existed but checked nothing.
   -------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION app.seed_standard_roles(p_tenant_id uuid)
RETURNS void LANGUAGE plpgsql AS $$
DECLARE
  v_role uuid;
BEGIN
  -- Administrator
  INSERT INTO roles (tenant_id, name, description, is_system)
  VALUES (p_tenant_id, 'Administrator', 'Full access to everything', true)
  ON CONFLICT (tenant_id, name) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO v_role;
  INSERT INTO role_permissions (role_id, permission_code)
  SELECT v_role, code FROM permissions
  ON CONFLICT DO NOTHING;

  -- HR manager: everything in HR except posting to the ledger.
  INSERT INTO roles (tenant_id, name, description, is_system)
  VALUES (p_tenant_id, 'HR manager', 'Runs HR and payroll, cannot post to the ledger', true)
  ON CONFLICT (tenant_id, name) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO v_role;
  INSERT INTO role_permissions (role_id, permission_code)
  SELECT v_role, unnest(ARRAY[
    'employee.read','employee.write','employee.id.reveal',
    'salary.read','salary.write','leave.read','leave.approve',
    'payroll.read','payroll.run'])
  ON CONFLICT DO NOTHING;

  -- Finance: posts payroll, reads salary, cannot edit people.
  INSERT INTO roles (tenant_id, name, description, is_system)
  VALUES (p_tenant_id, 'Finance', 'Approves and posts payroll to the ledger', true)
  ON CONFLICT (tenant_id, name) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO v_role;
  INSERT INTO role_permissions (role_id, permission_code)
  SELECT v_role, unnest(ARRAY[
    'employee.read','salary.read',
    'payroll.read','payroll.approve','payroll.post','audit.read'])
  ON CONFLICT DO NOTHING;

  -- Line manager: sees their team, approves leave, no salary at all.
  INSERT INTO roles (tenant_id, name, description, is_system)
  VALUES (p_tenant_id, 'Manager', 'Sees the team and approves leave', true)
  ON CONFLICT (tenant_id, name) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO v_role;
  INSERT INTO role_permissions (role_id, permission_code)
  SELECT v_role, unnest(ARRAY['employee.read','leave.read','leave.approve'])
  ON CONFLICT DO NOTHING;

  -- Staff: the directory, and nothing else.
  INSERT INTO roles (tenant_id, name, description, is_system)
  VALUES (p_tenant_id, 'Staff', 'Can see the employee directory', true)
  ON CONFLICT (tenant_id, name) DO UPDATE SET name = EXCLUDED.name
  RETURNING id INTO v_role;
  INSERT INTO role_permissions (role_id, permission_code)
  SELECT v_role, unnest(ARRAY['employee.read','leave.read'])
  ON CONFLICT DO NOTHING;
END $$;

/* --------------------------------------------------------------------------
   8. Housekeeping

   Expired sessions are deleted rather than left to accumulate. Run from
   cron; safe to call at any time.
   -------------------------------------------------------------------------- */

CREATE OR REPLACE FUNCTION app.purge_expired_sessions()
RETURNS integer LANGUAGE plpgsql AS $$
DECLARE n integer;
BEGIN
  DELETE FROM sessions
   WHERE expires_at < now() - interval '7 days'
      OR (revoked_at IS NOT NULL AND revoked_at < now() - interval '7 days');
  GET DIAGNOSTICS n = ROW_COUNT;
  RETURN n;
END $$;
