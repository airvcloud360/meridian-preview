/* ==========================================================================
   PLATFORM STUB — NOT PART OF THE DELIVERABLE

   The real Meridian platform already provides tenants, users, the chart of
   accounts, journals, and post_event(). This file recreates just enough of
   that surface to let 01_hr_core.sql be executed and tested in isolation.

   When the real backend archive is restored, DROP this file and run the HR
   migration against the genuine platform. The HR schema references only
   the columns recreated here, so it should attach without modification.
   ========================================================================== */

CREATE EXTENSION IF NOT EXISTS "pgcrypto";

CREATE SCHEMA IF NOT EXISTS app;

/* Current tenant, set per connection. The real platform sets this from the
   session token; here it is set manually in tests. */
CREATE OR REPLACE FUNCTION app.current_tenant() RETURNS uuid
LANGUAGE sql STABLE AS $$
  SELECT NULLIF(current_setting('app.tenant_id', true), '')::uuid
$$;

CREATE OR REPLACE FUNCTION app.current_user_id() RETURNS uuid
LANGUAGE sql STABLE AS $$
  SELECT NULLIF(current_setting('app.user_id', true), '')::uuid
$$;

CREATE TABLE tenants (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE users (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email       text NOT NULL UNIQUE,
  full_name   text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

/* Chart of accounts — payroll posts against these. */
CREATE TABLE accounts (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id   uuid NOT NULL REFERENCES tenants(id),
  code        text NOT NULL,
  name        text NOT NULL,
  type        text NOT NULL CHECK (type IN ('asset','liability','equity','income','expense')),
  UNIQUE (tenant_id, code)
);

CREATE TABLE journals (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id    uuid NOT NULL REFERENCES tenants(id),
  entry_date   date NOT NULL,
  memo         text,
  source_type  text,
  source_id    uuid,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE journal_lines (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  journal_id  uuid NOT NULL REFERENCES journals(id) ON DELETE CASCADE,
  account_id  uuid NOT NULL REFERENCES accounts(id),
  debit       numeric(18,2) NOT NULL DEFAULT 0 CHECK (debit  >= 0),
  credit      numeric(18,2) NOT NULL DEFAULT 0 CHECK (credit >= 0),
  CHECK (NOT (debit > 0 AND credit > 0))
);

/* Registry of tables that may never be updated or deleted from. The real
   platform reads this in its RLS reconciler; HR registers into it. */
CREATE TABLE IF NOT EXISTS app.append_only_tables (
  table_name  text PRIMARY KEY
);

/* Simplified post_event(): writes a balanced journal or raises. The real
   implementation does far more (periods, reversal, posting rules), but the
   contract HR depends on — balanced or nothing — is the same. */
CREATE OR REPLACE FUNCTION app.post_event(
  p_tenant_id   uuid,
  p_entry_date  date,
  p_memo        text,
  p_source_type text,
  p_source_id   uuid,
  p_lines       jsonb        -- [{"account_code":"5100","debit":100,"credit":0}, ...]
) RETURNS uuid
LANGUAGE plpgsql AS $$
DECLARE
  v_journal_id uuid;
  v_line       jsonb;
  v_account_id uuid;
  v_debits     numeric(18,2) := 0;
  v_credits    numeric(18,2) := 0;
BEGIN
  FOR v_line IN SELECT * FROM jsonb_array_elements(p_lines) LOOP
    v_debits  := v_debits  + COALESCE((v_line->>'debit')::numeric, 0);
    v_credits := v_credits + COALESCE((v_line->>'credit')::numeric, 0);
  END LOOP;

  IF v_debits <> v_credits THEN
    RAISE EXCEPTION 'Journal does not balance: debits %, credits %', v_debits, v_credits;
  END IF;

  IF v_debits = 0 THEN
    RAISE EXCEPTION 'Refusing to post a journal with no value';
  END IF;

  INSERT INTO journals (tenant_id, entry_date, memo, source_type, source_id)
  VALUES (p_tenant_id, p_entry_date, p_memo, p_source_type, p_source_id)
  RETURNING id INTO v_journal_id;

  FOR v_line IN SELECT * FROM jsonb_array_elements(p_lines) LOOP
    SELECT id INTO v_account_id
      FROM accounts
     WHERE tenant_id = p_tenant_id AND code = v_line->>'account_code';

    IF v_account_id IS NULL THEN
      RAISE EXCEPTION 'No account with code % for this tenant', v_line->>'account_code';
    END IF;

    INSERT INTO journal_lines (journal_id, account_id, debit, credit)
    VALUES (v_journal_id, v_account_id,
            COALESCE((v_line->>'debit')::numeric, 0),
            COALESCE((v_line->>'credit')::numeric, 0));
  END LOOP;

  RETURN v_journal_id;
END $$;
