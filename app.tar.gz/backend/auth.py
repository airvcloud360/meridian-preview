"""
Meridian ERP — authentication

Security code, so the reasoning is written down rather than assumed.

  * Passwords are bcrypt with cost 12. Cost is a deliberate slowness: it
    costs a legitimate user ~250ms once at login, and costs an attacker
    with a stolen hash table the same 250ms per guess.

  * Session tokens are 256 bits from secrets.token_urlsafe. They are
    returned to the client once and stored only as a SHA-256 hash. A dump
    of the sessions table yields nothing an attacker can replay.

  * Token comparison uses a constant-time compare. A normal == leaks
    information through how long it takes to fail, which is enough to
    reconstruct a token one byte at a time given enough attempts.

  * A wrong password and an unknown email return the same message and take
    the same time. Otherwise the login form becomes a way to discover who
    works at the company.

  * Failed attempts lock the account for 15 minutes after 5 tries. Without
    it, a weak password is a matter of time rather than luck.
"""

import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone
from typing import Optional

import bcrypt

# 12 rounds ≈ 250ms on typical server hardware. Raise it as hardware gets
# faster; existing hashes keep working because the cost is stored in them.
BCRYPT_ROUNDS = 12

SESSION_HOURS = 12          # a working day, so staff log in once a morning
MAX_FAILED_ATTEMPTS = 5
LOCKOUT_MINUTES = 15

# Used when no user matches, so an unknown email costs the same time as a
# wrong password. Without this, response timing tells an attacker which
# email addresses are real.
_DUMMY_HASH = bcrypt.hashpw(b"timing-equalisation", bcrypt.gensalt(rounds=BCRYPT_ROUNDS))


def hash_password(plain: str) -> str:
    if len(plain) < 10:
        raise ValueError("Password must be at least 10 characters")
    return bcrypt.hashpw(plain.encode(), bcrypt.gensalt(rounds=BCRYPT_ROUNDS)).decode()


def verify_password(plain: str, stored_hash: Optional[str]) -> bool:
    """Always does the work, even when there is no hash to check against."""
    if not stored_hash:
        bcrypt.checkpw(plain.encode(), _DUMMY_HASH)
        return False
    try:
        return bcrypt.checkpw(plain.encode(), stored_hash.encode())
    except ValueError:
        return False


def new_token() -> str:
    """256 bits of entropy. Long enough that guessing is not a strategy."""
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    """SHA-256, not bcrypt.

    Tokens are already high-entropy random values, so there is nothing for
    a slow hash to protect against — an attacker cannot guess a 256-bit
    random string regardless of how fast they can hash. Using bcrypt here
    would cost 250ms on every single API request for no security gain.
    """
    return hashlib.sha256(token.encode()).hexdigest()


def tokens_match(supplied: str, stored_hash: str) -> bool:
    return hmac.compare_digest(hash_token(supplied), stored_hash)


class AuthError(Exception):
    """Authentication failed. The message is deliberately vague."""


class PermissionDenied(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(f"You do not have permission to do this ({code})")


# ---------------------------------------------------------------------------
# Login
# ---------------------------------------------------------------------------

def login(cur, email: str, password: str,
          ip: Optional[str] = None, user_agent: Optional[str] = None) -> dict:
    """Returns a session token, or raises AuthError.

    Every failure path raises the same message. The audit log records what
    actually happened; the caller is told only that it did not work.
    """
    email = (email or "").strip().lower()

    cur.execute(
        """SELECT id, tenant_id, email, full_name, password_hash, is_active,
                  failed_attempts, locked_until, must_change_password
             FROM users WHERE lower(email) = %s""",
        [email])
    user = cur.fetchone()

    now = datetime.now(timezone.utc)

    if user is None:
        # Spend the same time as a real check so timing says nothing.
        verify_password(password, None)
        _audit(cur, None, None, "login.failed",
               detail={"email": email, "reason": "no such user"}, ip=ip)
        raise AuthError("Email or password is incorrect")

    if user["locked_until"] and user["locked_until"] > now:
        _audit(cur, user["tenant_id"], user["id"], "login.blocked",
               detail={"reason": "account locked"}, ip=ip)
        raise AuthError(
            "This account is temporarily locked after repeated failed "
            "attempts. Try again shortly.")

    if not user["is_active"]:
        verify_password(password, None)
        _audit(cur, user["tenant_id"], user["id"], "login.failed",
               detail={"reason": "account disabled"}, ip=ip)
        raise AuthError("Email or password is incorrect")

    if not verify_password(password, user["password_hash"]):
        attempts = user["failed_attempts"] + 1
        lock_until = (now + timedelta(minutes=LOCKOUT_MINUTES)
                      if attempts >= MAX_FAILED_ATTEMPTS else None)
        cur.execute(
            "UPDATE users SET failed_attempts = %s, locked_until = %s WHERE id = %s",
            [attempts, lock_until, user["id"]])
        _audit(cur, user["tenant_id"], user["id"], "login.failed",
               detail={"reason": "wrong password", "attempt": attempts}, ip=ip)
        raise AuthError("Email or password is incorrect")

    # Success. Clear the counter and issue a session.
    token = new_token()
    cur.execute(
        """UPDATE users
              SET failed_attempts = 0, locked_until = NULL, last_login_at = now()
            WHERE id = %s""",
        [user["id"]])

    cur.execute(
        """INSERT INTO sessions
             (user_id, tenant_id, token_hash, expires_at, ip, user_agent)
           VALUES (%s, %s, %s, %s, %s, %s)
           RETURNING id, expires_at""",
        [user["id"], user["tenant_id"], hash_token(token),
         now + timedelta(hours=SESSION_HOURS), ip, user_agent])
    session = cur.fetchone()

    _audit(cur, user["tenant_id"], user["id"], "login.success", ip=ip)

    return {
        "token": token,
        "expires_at": session["expires_at"],
        "user": {
            "id": str(user["id"]),
            "email": user["email"],
            "full_name": user["full_name"],
            "tenant_id": str(user["tenant_id"]),
            "must_change_password": user["must_change_password"],
        },
        "permissions": permissions_for(cur, user["id"]),
    }


def resolve_session(cur, token: Optional[str]) -> dict:
    """Turns a bearer token into a session, or raises.

    Also sets app.user_id and app.tenant_id on the connection, which is
    what the row-level security policies read. Every request that reaches
    a query has already been scoped to one tenant by this point.
    """
    if not token:
        raise AuthError("Not signed in")

    cur.execute(
        """SELECT s.id, s.user_id, s.tenant_id, s.expires_at, s.revoked_at,
                  u.is_active, u.email, u.full_name
             FROM sessions s
             JOIN users u ON u.id = s.user_id
            WHERE s.token_hash = %s""",
        [hash_token(token)])
    s = cur.fetchone()

    if s is None:
        raise AuthError("Session is not valid")
    if s["revoked_at"] is not None:
        raise AuthError("Session has been signed out")
    if s["expires_at"] <= datetime.now(timezone.utc):
        raise AuthError("Session has expired. Please sign in again.")
    if not s["is_active"]:
        raise AuthError("This account is no longer active")

    cur.execute("UPDATE sessions SET last_seen_at = now() WHERE id = %s", [s["id"]])

    # These drive row-level security for the rest of the transaction.
    cur.execute("SELECT set_config('app.user_id', %s, true)", [str(s["user_id"])])
    cur.execute("SELECT set_config('app.tenant_id', %s, true)", [str(s["tenant_id"])])

    return {
        "session_id": str(s["id"]),
        "user_id": str(s["user_id"]),
        "tenant_id": str(s["tenant_id"]),
        "email": s["email"],
        "full_name": s["full_name"],
        "permissions": permissions_for(cur, s["user_id"]),
    }


def logout(cur, token: str) -> None:
    cur.execute(
        """UPDATE sessions SET revoked_at = now()
            WHERE token_hash = %s AND revoked_at IS NULL
            RETURNING user_id, tenant_id""",
        [hash_token(token)])
    row = cur.fetchone()
    if row:
        _audit(cur, row["tenant_id"], row["user_id"], "logout")


def logout_everywhere(cur, user_id: str) -> int:
    """Revokes every session for a user. What "sign out of all devices"
    calls, and what should happen automatically on a password change."""
    cur.execute(
        """UPDATE sessions SET revoked_at = now()
            WHERE user_id = %s AND revoked_at IS NULL""",
        [user_id])
    return cur.rowcount


# ---------------------------------------------------------------------------
# Permissions
# ---------------------------------------------------------------------------

def permissions_for(cur, user_id) -> list:
    cur.execute(
        """SELECT DISTINCT rp.permission_code AS code
             FROM user_roles ur
             JOIN role_permissions rp ON rp.role_id = ur.role_id
            WHERE ur.user_id = %s
            ORDER BY 1""",
        [user_id])
    return [r["code"] for r in cur.fetchall()]


def require(session: dict, code: str) -> None:
    if code not in session.get("permissions", []):
        raise PermissionDenied(code)


def can(session: dict, code: str) -> bool:
    return code in session.get("permissions", [])


# ---------------------------------------------------------------------------
# Passwords
# ---------------------------------------------------------------------------

def change_password(cur, user_id: str, current: str, new: str) -> None:
    """Changing a password signs out every other session.

    If the reason for the change is that someone else knew the old one,
    leaving their session alive defeats the point.
    """
    cur.execute("SELECT password_hash, tenant_id FROM users WHERE id = %s", [user_id])
    row = cur.fetchone()
    if not row:
        raise AuthError("No such user")

    if not verify_password(current, row["password_hash"]):
        _audit(cur, row["tenant_id"], user_id, "password.change.failed")
        raise AuthError("Current password is incorrect")

    if current == new:
        raise ValueError("The new password must be different from the old one")

    cur.execute(
        """UPDATE users
              SET password_hash = %s, password_changed_at = now(),
                  must_change_password = false
            WHERE id = %s""",
        [hash_password(new), user_id])

    logout_everywhere(cur, user_id)
    _audit(cur, row["tenant_id"], user_id, "password.changed")


def create_user(cur, tenant_id: str, email: str, full_name: str,
                password: str, role_names: list,
                created_by: Optional[str] = None) -> str:
    email = email.strip().lower()
    cur.execute(
        """INSERT INTO users
             (tenant_id, email, full_name, password_hash, must_change_password)
           VALUES (%s, %s, %s, %s, true)
           RETURNING id""",
        [tenant_id, email, full_name, hash_password(password)])
    user_id = cur.fetchone()["id"]

    for name in role_names:
        cur.execute(
            """INSERT INTO user_roles (user_id, role_id, granted_by)
               SELECT %s, id, %s FROM roles
                WHERE tenant_id = %s AND name = %s""",
            [user_id, created_by, tenant_id, name])

    _audit(cur, tenant_id, created_by, "user.created",
           object_type="user", object_id=user_id,
           detail={"email": email, "roles": role_names})
    return str(user_id)


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------

def _audit(cur, tenant_id, user_id, action, object_type=None, object_id=None,
           detail=None, ip=None) -> None:
    import json
    cur.execute(
        """INSERT INTO audit_log
             (tenant_id, user_id, action, object_type, object_id, detail, ip)
           VALUES (%s, %s, %s, %s, %s, %s, %s)""",
        [tenant_id, user_id, action, object_type, object_id,
         json.dumps(detail) if detail else None, ip])


def audit(cur, session: dict, action: str, object_type=None, object_id=None,
          detail=None, ip=None) -> None:
    """Public form, for routes to record what a signed-in user did."""
    _audit(cur, session["tenant_id"], session["user_id"], action,
           object_type, object_id, detail, ip)
