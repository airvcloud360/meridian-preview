"""
Meridian ERP — HR API

The bridge between the screens and the database. Every "Save" button in the
HR module eventually calls something in this file.

Design notes worth knowing:

  * Validation lives in the database, not here. This layer translates
    database errors into readable messages, but it does not re-implement
    the rules. Two copies of a rule become two different rules.

  * A salary change is never an UPDATE. PUT /employees/{id}/salary closes
    the current structure and opens a new one, so last year's payslips
    stay explainable.

  * Statutory ID numbers are masked on read unless the caller explicitly
    asks and is allowed. A directory listing is seen by more people than
    should see a full PAN.
"""

import os
import re
from contextlib import contextmanager
from datetime import date
from typing import Optional, List
from decimal import Decimal

import psycopg2
import psycopg2.extras
from fastapi import FastAPI, HTTPException, Query, Header, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field, field_validator

import auth as A

psycopg2.extras.register_uuid()

DSN = os.environ.get(
    "MERIDIAN_DSN",
    "host=127.0.0.1 dbname=meridian user=postgres password=meridian_dev",
)

app = FastAPI(title="Meridian HR API", version="1.0")

# The preview is served from a different origin than the API, so the browser
# needs permission to call it. Tighten this to the real domain before launch.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

bearer = HTTPBearer(auto_error=False)


@contextmanager
def db(session: Optional[dict] = None):
    """Opens a connection, scoped to the caller's tenant.

    Every route opens its own connection, so the tenant has to be stamped
    onto each one. Setting it once at login stamps a connection that is
    closed moments later, and every query after that runs with no tenant.
    Under row-level security that does not fail loudly — it silently
    returns nothing, which reads as missing data rather than as a bug.

    The session is passed in explicitly rather than carried in a
    ContextVar: FastAPI runs sync dependencies and sync endpoints in
    different threadpool threads, and a value set inside a dependency does
    not propagate back out. Explicit beats invisible here, especially for
    the thing standing between two companies' data.
    """
    conn = psycopg2.connect(DSN)
    conn.autocommit = False
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            if session:
                cur.execute("SELECT set_config('app.user_id', %s, true)",
                            [str(session["user_id"])])
                cur.execute("SELECT set_config('app.tenant_id', %s, true)",
                            [str(session["tenant_id"])])
            yield cur
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def db_error(exc: Exception) -> HTTPException:
    """Turn a database constraint failure into something a person can act on.

    The database messages are precise but not friendly. Where we recognise
    one, we say what actually went wrong and what to do about it; where we
    don't, we pass the original through rather than inventing an
    explanation.
    """
    msg = str(exc)

    known = [
        ("no_overlapping_salary",
         "This overlaps an existing salary period. Close the current one first."),
        ("no_overlapping_approved_leave",
         "This person already has approved leave covering some of those dates."),
        ("no_self_approval",
         "Leave cannot be approved by the person who requested it."),
        ("hr_employees_tenant_id_employee_code_key",
         "That employee code is already in use."),
        ("hr_employees_email_key",
         "That email address is already in use."),
        # Payroll state errors are conflicts, not bad input — the request was
        # well formed, the run is simply not in a state that allows it.
        ("must be approved before posting",
         "This run has not been approved yet. Compute it, check it, then "
         "approve it before posting."),
        ("is already posted",
         "This payroll run has already been posted to the ledger."),
        ("can no longer be recomputed",
         "This run is approved or posted and can no longer be recomputed."),
        ("Nothing to post",
         "This run has no payslips. Compute it first."),
        ("exit_date_matches_status",
         "An employee marked as exited needs an exit date, and only an exited "
         "employee may have one."),
        ("exit_after_joining",
         "The exit date cannot be before the joining date."),
        ("Reporting line would form a loop",
         "That reporting line loops back on itself."),
        ("posted payroll run cannot be reopened",
         "This payroll run is posted. Post a correcting adjustment instead."),
        ("belongs to a posted payroll run",
         "This payslip is posted and cannot be changed. Post a correcting "
         "adjustment in a later run instead."),
        ("hr_payroll_one_live_run",
         "A payroll run already exists for that month."),
        ("has no salary structure",
         None),   # the database message here is already clear and specific
    ]

    for needle, friendly in known:
        if needle in msg:
            detail = friendly or msg.split("CONTEXT:")[0].strip()
            return HTTPException(status_code=409, detail=detail)

    return HTTPException(status_code=400, detail=msg.split("CONTEXT:")[0].strip())


def client_ip(request: Request) -> Optional[str]:
    fwd = request.headers.get("x-forwarded-for")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else None


def current_session(
    request: Request,
    creds: Optional[HTTPAuthorizationCredentials] = Depends(bearer),
) -> dict:
    """Resolves the bearer token to a session, or refuses the request.

    Every route that touches data depends on this. A route without it is
    a route anyone on the internet can call, so the absence of this
    dependency is itself the bug — there is a test that walks the route
    table and fails if any data route is missing it.

    resolve_session also sets app.user_id and app.tenant_id on the
    connection, which is what the row-level security policies read. That
    is the backstop: even a route that forgets its tenant filter cannot
    return another company's rows.
    """
    token = creds.credentials if creds else None
    with db() as cur:
        try:
            session = A.resolve_session(cur, token)
        except A.AuthError as exc:
            raise HTTPException(401, str(exc))
    session["ip"] = client_ip(request)
    return session


def require(session: dict, code: str) -> None:
    """Raises 403 with a message that says what is missing and what to do."""
    if code not in session.get("permissions", []):
        raise HTTPException(
            403,
            f"Your role does not include '{code}'. "
            f"Ask an administrator if you need this.",
        )


def _own_run(cur, run_id: str, session: dict) -> None:
    """Confirms a payroll run belongs to the caller's tenant.

    The database functions take a run id and do not check tenancy, so this
    is checked before calling them. RLS is the backstop, not the excuse
    for skipping it.
    """
    cur.execute("SELECT 1 FROM hr_payroll_runs WHERE id = %s AND tenant_id = %s",
                [run_id, session["tenant_id"]])
    if not cur.fetchone():
        raise HTTPException(404, "No payroll run with that id")


def scoped(session: dict) -> str:
    """The tenant of the signed-in user. Routes take the tenant from the
    session, never from a query parameter — a client-supplied tenant_id is
    an invitation to read someone else's data."""
    return session["tenant_id"]


# ---------------------------------------------------------------------------
# Sign in and out
# ---------------------------------------------------------------------------

class LoginIn(BaseModel):
    email: str
    password: str


class PasswordChangeIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=10)


@app.post("/api/auth/login")
def login(body: LoginIn, request: Request):
    with db() as cur:
        try:
            return A.login(cur, body.email, body.password,
                           ip=client_ip(request),
                           user_agent=request.headers.get("user-agent", "")[:400])
        except A.AuthError as exc:
            # 429 for a lockout so a client can tell "wait" from "wrong".
            code = 429 if "locked" in str(exc).lower() else 401
            raise HTTPException(code, str(exc))


@app.post("/api/auth/logout")
def logout(request: Request,
           creds: HTTPAuthorizationCredentials = Depends(bearer),
           session: dict = Depends(current_session)):
    with db(session) as cur:
        A.logout(cur, creds.credentials)
    return {"status": "signed out"}


@app.get("/api/auth/me")
def whoami(session: dict = Depends(current_session)):
    """What the front end needs to decide which buttons to render.

    The permission list here is a convenience for the UI, not a control.
    Hiding a button the user cannot use is courtesy; the server refusing
    the call is the actual security.
    """
    return {
        "user_id": session["user_id"],
        "tenant_id": session["tenant_id"],
        "email": session.get("email"),
        "full_name": session.get("full_name"),
        "permissions": session.get("permissions", []),
    }


@app.post("/api/auth/password")
def change_password(body: PasswordChangeIn, request: Request,
                    session: dict = Depends(current_session)):
    with db(session) as cur:
        try:
            A.change_password(cur, session["user_id"],
                              body.current_password, body.new_password)
        except A.AuthError as exc:
            raise HTTPException(400, str(exc))
        A.audit(cur, session, "auth.password_changed", ip=session.get("ip"))
    return {"status": "password changed"}


def mask_id(value: Optional[str]) -> Optional[str]:
    """ABCPS1234F -> ABCP••••4F. Mirrors maskId() in the front end."""
    if not value or len(value) <= 6:
        return value
    return value[:4] + "•" * (len(value) - 6) + value[-2:]


# ---------------------------------------------------------------------------
# Request bodies
# ---------------------------------------------------------------------------

class EmployeeIn(BaseModel):
    employee_code: str = Field(min_length=1, max_length=32)
    full_name: str = Field(min_length=1, max_length=200)
    email: Optional[str] = None
    phone: Optional[str] = None
    department_id: Optional[str] = None
    designation_id: Optional[str] = None
    manager_id: Optional[str] = None
    employment_type: str = "full_time"
    status: str = "active"
    date_of_joining: date
    date_of_exit: Optional[date] = None
    pan: Optional[str] = None
    aadhaar: Optional[str] = None
    bank_account_no: Optional[str] = None
    bank_ifsc: Optional[str] = None

    @field_validator("pan")
    @classmethod
    def pan_shape(cls, v):
        if v and not re.fullmatch(r"[A-Z]{5}[0-9]{4}[A-Z]", v.upper()):
            raise ValueError("PAN should look like ABCDE1234F")
        return v.upper() if v else v

    @field_validator("email")
    @classmethod
    def email_shape(cls, v):
        if v and "@" not in v:
            raise ValueError("That does not look like an email address")
        return v.lower().strip() if v else v


class EmployeePatch(BaseModel):
    """Every field optional — this is a partial edit from the profile screen."""
    full_name: Optional[str] = None
    email: Optional[str] = None
    phone: Optional[str] = None
    department_id: Optional[str] = None
    designation_id: Optional[str] = None
    manager_id: Optional[str] = None
    employment_type: Optional[str] = None
    status: Optional[str] = None
    date_of_exit: Optional[date] = None
    pan: Optional[str] = None
    bank_account_no: Optional[str] = None
    bank_ifsc: Optional[str] = None


class SalaryIn(BaseModel):
    effective_from: date
    basic: Decimal = Field(ge=0)
    hra: Decimal = Field(default=0, ge=0)
    allowances: Decimal = Field(default=0, ge=0)
    pf_employee: Decimal = Field(default=0, ge=0)
    pf_employer: Decimal = Field(default=0, ge=0)
    professional_tax: Decimal = Field(default=0, ge=0)
    notes: Optional[str] = None


class LeaveIn(BaseModel):
    leave_type_id: str
    start_date: date
    end_date: date
    days: Decimal = Field(gt=0)
    reason: Optional[str] = None


class LeaveDecision(BaseModel):
    approve: bool
    approver_id: str
    note: Optional[str] = None


# ---------------------------------------------------------------------------
# Employees
# ---------------------------------------------------------------------------

@app.get("/api/employees")
def list_employees(
    session: dict = Depends(current_session),
    q: Optional[str] = None,
    department_id: Optional[str] = None,
    status: Optional[str] = None,
    limit: int = Query(50, le=200),
    offset: int = 0,
):
    """The directory screen. Paginated, because a 500-person company should
    not send 500 rows to a phone on every keystroke."""
    require(session, "employee.read")
    tenant_id = scoped(session)

    where = ["e.tenant_id = %s"]
    args: list = [tenant_id]

    if q:
        where.append("e.full_name ILIKE %s")
        args.append(f"%{q}%")
    if department_id:
        where.append("e.department_id = %s")
        args.append(department_id)
    if status:
        where.append("e.status = %s")
        args.append(status)

    clause = " AND ".join(where)

    with db(session) as cur:
        cur.execute(f"SELECT COUNT(*) AS n FROM hr_employees e WHERE {clause}", args)
        total = cur.fetchone()["n"]

        cur.execute(
            f"""
            SELECT e.id, e.employee_code, e.full_name, e.status,
                   e.date_of_joining, e.email, e.phone,
                   d.name  AS department,
                   g.title AS designation
              FROM hr_employees e
              LEFT JOIN hr_departments  d ON d.id = e.department_id
              LEFT JOIN hr_designations g ON g.id = e.designation_id
             WHERE {clause}
             ORDER BY e.employee_code
             LIMIT %s OFFSET %s
            """,
            args + [limit, offset],
        )
        rows = cur.fetchall()

        cur.execute(
            """
            SELECT COUNT(*) FILTER (WHERE status = 'active')        AS active,
                   COUNT(*) FILTER (WHERE status = 'on_leave')      AS on_leave,
                   COUNT(*) FILTER (WHERE status = 'notice_period') AS notice,
                   COUNT(*)                                          AS headcount
              FROM hr_employees WHERE tenant_id = %s
            """,
            [tenant_id],
        )
        counts = cur.fetchone()

    return {"total": total, "counts": counts, "employees": rows}


@app.get("/api/employees/{employee_id}")
def get_employee(employee_id: str, reveal_ids: bool = False,
                 session: dict = Depends(current_session)):
    """The profile screen. ID numbers come back masked unless explicitly
    requested — the caller has to ask, which makes the access auditable."""
    require(session, "employee.read")

    # Revealing an ID number is a separate permission from reading the
    # record, and asking for it without holding it is refused rather than
    # silently downgraded — a caller that thinks it got real data and did
    # not is worse than an error.
    if reveal_ids:
        require(session, "employee.id.reveal")

    with db(session) as cur:
        cur.execute(
            """
            SELECT e.*, d.name AS department, g.title AS designation,
                   m.full_name AS manager_name
              FROM hr_employees e
              LEFT JOIN hr_departments  d ON d.id = e.department_id
              LEFT JOIN hr_designations g ON g.id = e.designation_id
              LEFT JOIN hr_employees    m ON m.id = e.manager_id
             WHERE e.id = %s AND e.tenant_id = %s
            """,
            [employee_id, scoped(session)],
        )
        emp = cur.fetchone()
        if not emp:
            raise HTTPException(404, "No employee with that id")

        cur.execute(
            """
            SELECT id, effective_from, effective_to, basic, hra, allowances,
                   pf_employee, pf_employer, professional_tax, notes,
                   (basic + hra + allowances) AS gross_annual,
                   (basic + hra + allowances - pf_employee - professional_tax)
                     AS net_annual
              FROM hr_salary_structures
             WHERE employee_id = %s
             ORDER BY effective_from DESC
            """,
            [employee_id],
        )
        salary_history = cur.fetchall() if A.can(session, "salary.read") else []

        cur.execute(
            """
            SELECT lt.id AS leave_type_id, lt.name, lt.is_paid,
                   COALESCE(en.days_granted, 0) AS granted,
                   hr_leave_balance(%s, lt.id, EXTRACT(YEAR FROM CURRENT_DATE)::int)
                     AS remaining
              FROM hr_leave_types lt
              LEFT JOIN hr_leave_entitlements en
                     ON en.leave_type_id = lt.id
                    AND en.employee_id = %s
                    AND en.year = EXTRACT(YEAR FROM CURRENT_DATE)::int
             WHERE lt.tenant_id = %s AND lt.is_active
             ORDER BY lt.name
            """,
            [employee_id, employee_id, emp["tenant_id"]],
        )
        leave = cur.fetchall()

    emp = dict(emp)
    if not reveal_ids:
        for field in ("pan", "aadhaar", "uan", "esic_number", "bank_account_no"):
            emp[field] = mask_id(emp.get(field))
    else:
        # Who looked at whose PAN, and when. This is the record that makes
        # the permission meaningful after the fact.
        with db(session) as cur:
            A.audit(cur, session, "employee.id.reveal", "hr_employees",
                    employee_id, {"employee_code": emp.get("employee_code")},
                    ip=session.get("ip"))

    return {
        "employee": emp,
        "salary_current": salary_history[0] if salary_history else None,
        "salary_history": salary_history,
        "leave": leave,
    }


@app.post("/api/employees", status_code=201)
def create_employee(body: EmployeeIn, session: dict = Depends(current_session)):
    require(session, "employee.write")
    fields = body.model_dump(exclude_none=True)
    fields["tenant_id"] = scoped(session)
    cols = ", ".join(fields)
    holes = ", ".join(["%s"] * len(fields))

    try:
        with db(session) as cur:
            cur.execute(
                f"INSERT INTO hr_employees ({cols}) VALUES ({holes}) RETURNING id",
                list(fields.values()),
            )
            new_id = cur.fetchone()["id"]
            A.audit(cur, session, "employee.create", "hr_employees", new_id,
                    {"employee_code": fields.get("employee_code")},
                    ip=session.get("ip"))
            return {"id": new_id}
    except Exception as exc:
        raise db_error(exc)


@app.patch("/api/employees/{employee_id}")
def update_employee(employee_id: str, body: EmployeePatch,
                    session: dict = Depends(current_session)):
    require(session, "employee.write")
    """Partial edit. Only the fields actually sent are touched, so two people
    editing different parts of a record do not overwrite each other."""
    fields = body.model_dump(exclude_unset=True)
    if not fields:
        raise HTTPException(400, "Nothing to update")

    if "pan" in fields and fields["pan"]:
        pan = fields["pan"].upper()
        if not re.fullmatch(r"[A-Z]{5}[0-9]{4}[A-Z]", pan):
            raise HTTPException(400, "PAN should look like ABCDE1234F")
        fields["pan"] = pan

    sets = ", ".join(f"{k} = %s" for k in fields)
    try:
        with db(session) as cur:
            cur.execute(
                f"UPDATE hr_employees SET {sets} "
                f"WHERE id = %s AND tenant_id = %s RETURNING id",
                list(fields.values()) + [employee_id, scoped(session)],
            )
            if not cur.fetchone():
                raise HTTPException(404, "No employee with that id")
            # Field names only. The audit log records that a phone number
            # changed, not what it changed to — a log full of the data it
            # is protecting is a second copy to leak.
            A.audit(cur, session, "employee.update", "hr_employees",
                    employee_id, {"fields": sorted(fields)},
                    ip=session.get("ip"))
    except HTTPException:
        raise
    except Exception as exc:
        raise db_error(exc)

    return get_employee(employee_id, session=session)


# ---------------------------------------------------------------------------
# Salary
# ---------------------------------------------------------------------------

@app.put("/api/employees/{employee_id}/salary", status_code=201)
def revise_salary(employee_id: str, body: SalaryIn,
                  session: dict = Depends(current_session)):
    require(session, "salary.write")
    """A raise. Closes the current structure the day the new one starts and
    inserts the new one — never an UPDATE, so past payslips stay explainable.

    Both steps happen in one transaction. A half-applied raise would leave
    either a gap or an overlap, and the database would reject the second
    anyway."""
    try:
        with db(session) as cur:
            cur.execute(
                "SELECT tenant_id FROM hr_employees WHERE id = %s AND tenant_id = %s",
                [employee_id, scoped(session)])
            row = cur.fetchone()
            if not row:
                raise HTTPException(404, "No employee with that id")
            tenant_id = row["tenant_id"]

            cur.execute(
                """
                UPDATE hr_salary_structures
                   SET effective_to = %s
                 WHERE employee_id = %s AND effective_to IS NULL
                   AND effective_from < %s
                """,
                [body.effective_from, employee_id, body.effective_from],
            )

            f = body.model_dump()
            f["tenant_id"] = tenant_id
            f["employee_id"] = employee_id
            cols = ", ".join(f)
            holes = ", ".join(["%s"] * len(f))
            cur.execute(
                f"INSERT INTO hr_salary_structures ({cols}) VALUES ({holes}) RETURNING id",
                list(f.values()),
            )
            sal_id = cur.fetchone()["id"]
            A.audit(cur, session, "salary.revise", "hr_salary_structures",
                    sal_id, {"employee_id": str(employee_id),
                             "effective_from": str(body.effective_from)},
                    ip=session.get("ip"))
            return {"id": sal_id}
    except HTTPException:
        raise
    except Exception as exc:
        raise db_error(exc)


# ---------------------------------------------------------------------------
# Leave
# ---------------------------------------------------------------------------

@app.post("/api/employees/{employee_id}/leave", status_code=201)
def request_leave(employee_id: str, body: LeaveIn,
                  session: dict = Depends(current_session)):
    require(session, "leave.read")
    try:
        with db(session) as cur:
            cur.execute(
                "SELECT tenant_id FROM hr_employees WHERE id = %s AND tenant_id = %s",
                [employee_id, scoped(session)])
            row = cur.fetchone()
            if not row:
                raise HTTPException(404, "No employee with that id")

            cur.execute(
                """
                INSERT INTO hr_leave_requests
                  (tenant_id, employee_id, leave_type_id, start_date, end_date,
                   days, reason, status)
                VALUES (%s, %s, %s, %s, %s, %s, %s, 'pending')
                RETURNING id
                """,
                [row["tenant_id"], employee_id, body.leave_type_id,
                 body.start_date, body.end_date, body.days, body.reason],
            )
            return {"id": cur.fetchone()["id"]}
    except HTTPException:
        raise
    except Exception as exc:
        raise db_error(exc)


@app.post("/api/leave/{request_id}/decision")
def decide_leave(request_id: str, body: LeaveDecision,
                 session: dict = Depends(current_session)):
    require(session, "leave.approve")
    status = "approved" if body.approve else "rejected"
    try:
        with db(session) as cur:
            cur.execute(
                """
                UPDATE hr_leave_requests
                   SET status = %s, approver_id = %s,
                       decided_at = now(), decision_note = %s
                 WHERE id = %s AND status = 'pending' AND tenant_id = %s
                 RETURNING id, status
                """,
                [status, body.approver_id, body.note, request_id, scoped(session)],
            )
            row = cur.fetchone()
            if not row:
                raise HTTPException(
                    409, "That request is not pending — it may already be decided.")
            A.audit(cur, session, f"leave.{status}", "hr_leave_requests",
                    request_id, ip=session.get("ip"))
            return row
    except HTTPException:
        raise
    except Exception as exc:
        raise db_error(exc)


# ---------------------------------------------------------------------------
# Payroll
# ---------------------------------------------------------------------------

@app.post("/api/payroll/runs", status_code=201)
def create_run(year: int, month: int, session: dict = Depends(current_session)):
    require(session, "payroll.run")
    tenant_id = scoped(session)
    try:
        with db(session) as cur:
            cur.execute(
                """INSERT INTO hr_payroll_runs (tenant_id, period_year, period_month)
                   VALUES (%s, %s, %s) RETURNING id""",
                [tenant_id, year, month],
            )
            return {"id": cur.fetchone()["id"]}
    except Exception as exc:
        raise db_error(exc)


@app.post("/api/payroll/runs/{run_id}/compute")
def compute_run(run_id: str, session: dict = Depends(current_session)):
    require(session, "payroll.run")
    try:
        with db(session) as cur:
            _own_run(cur, run_id, session)
            cur.execute("SELECT hr_compute_payroll(%s) AS n", [run_id])
            n = cur.fetchone()["n"]
            A.audit(cur, session, "payroll.compute", "hr_payroll_runs",
                    run_id, {"payslips": n}, ip=session.get("ip"))
            return {"payslips": n}
    except Exception as exc:
        raise db_error(exc)


@app.post("/api/payroll/runs/{run_id}/approve")
def approve_run(run_id: str, session: dict = Depends(current_session)):
    require(session, "payroll.approve")
    user_id = session["user_id"]
    with db(session) as cur:
        _own_run(cur, run_id, session)
        cur.execute(
            """UPDATE hr_payroll_runs
                  SET status = 'approved', approved_at = now(), approved_by = %s
                WHERE id = %s AND status = 'computed'
                RETURNING id, status""",
            [user_id, run_id],
        )
        row = cur.fetchone()
        if not row:
            raise HTTPException(
                409, "Only a computed run can be approved. Compute it first.")
        A.audit(cur, session, "payroll.approve", "hr_payroll_runs", run_id,
                ip=session.get("ip"))
        return row


@app.post("/api/payroll/runs/{run_id}/post")
def post_run(run_id: str, session: dict = Depends(current_session)):
    """The point of no return. After this the payslips are history.

    Deliberately a different permission from approve: whoever prepares the
    money should not also be the one who releases it.
    """
    require(session, "payroll.post")
    try:
        with db(session) as cur:
            _own_run(cur, run_id, session)
            cur.execute("SELECT hr_post_payroll(%s, %s) AS journal_id",
                        [run_id, session["user_id"]])
            jid = cur.fetchone()["journal_id"]
            A.audit(cur, session, "payroll.post", "hr_payroll_runs", run_id,
                    {"journal_id": str(jid)}, ip=session.get("ip"))
            return {"journal_id": jid}
    except Exception as exc:
        raise db_error(exc)


@app.get("/api/payroll/runs/{run_id}")
def get_run(run_id: str, session: dict = Depends(current_session)):
    require(session, "payroll.read")
    with db(session) as cur:
        cur.execute("SELECT * FROM hr_payroll_runs WHERE id = %s AND tenant_id = %s",
                    [run_id, scoped(session)])
        run = cur.fetchone()
        if not run:
            raise HTTPException(404, "No payroll run with that id")

        cur.execute(
            """SELECT p.*, e.employee_code, e.full_name
                 FROM hr_payslips p
                 JOIN hr_employees e ON e.id = p.employee_id
                WHERE p.payroll_run_id = %s
                ORDER BY e.employee_code""",
            [run_id],
        )
        return {"run": run, "payslips": cur.fetchall()}


# ---------------------------------------------------------------------------
# Reference data — the dropdowns every edit form needs
# ---------------------------------------------------------------------------

@app.get("/api/reference")
def reference(session: dict = Depends(current_session)):
    require(session, "employee.read")
    tenant_id = scoped(session)
    with db(session) as cur:
        cur.execute(
            "SELECT id, name FROM hr_departments WHERE tenant_id=%s AND is_active ORDER BY name",
            [tenant_id])
        departments = cur.fetchall()
        cur.execute(
            "SELECT id, title FROM hr_designations WHERE tenant_id=%s AND is_active ORDER BY title",
            [tenant_id])
        designations = cur.fetchall()
        cur.execute(
            "SELECT id, name, is_paid FROM hr_leave_types WHERE tenant_id=%s AND is_active ORDER BY name",
            [tenant_id])
        leave_types = cur.fetchall()
        cur.execute(
            "SELECT id, employee_code, full_name FROM hr_employees WHERE tenant_id=%s AND status='active' ORDER BY full_name",
            [tenant_id])
        managers = cur.fetchall()

    return {
        "departments": departments,
        "designations": designations,
        "leave_types": leave_types,
        "managers": managers,
        "employment_types": ["full_time", "part_time", "contract", "intern", "consultant"],
        "statuses": ["active", "on_leave", "notice_period", "suspended", "exited"],
    }


@app.get("/api/health")
def health():
    with db() as cur:
        cur.execute("SELECT 1 AS ok")
        cur.fetchone()
    return {"status": "ok"}


# ---------------------------------------------------------------------------
# PDF documents
#
# Browser printing covers ad-hoc reports. These three are generated server
# side because they are emailed, filed, and sometimes shown to a bank or a
# tribunal — they have to render identically regardless of who printed them.
# ---------------------------------------------------------------------------

from fastapi.responses import Response  # noqa: E402
from pdf_reports import (  # noqa: E402
    payslip_pdf, payroll_register_pdf, employee_profile_pdf,
)


def _pdf(content: bytes, filename: str) -> Response:
    """inline rather than attachment, so the browser previews it. The user
    can still save from the viewer, and previewing first is what most
    people actually want."""
    return Response(
        content=content,
        media_type="application/pdf",
        headers={"Content-Disposition": f'inline; filename="{filename}"'},
    )


def _company_name(cur, tenant_id) -> str:
    cur.execute("SELECT name FROM tenants WHERE id = %s", [tenant_id])
    row = cur.fetchone()
    return row["name"] if row else "Meridian"


@app.get("/api/payslips/{payslip_id}/pdf")
def payslip_document(payslip_id: str, session: dict = Depends(current_session)):
    require(session, "payroll.read")
    with db(session) as cur:
        cur.execute(
            """SELECT p.*, e.employee_code, e.full_name,
                      d.name AS department, g.title AS designation
                 FROM hr_payslips p
                 JOIN hr_employees e ON e.id = p.employee_id
                 LEFT JOIN hr_departments  d ON d.id = e.department_id
                 LEFT JOIN hr_designations g ON g.id = e.designation_id
                WHERE p.id = %s AND p.tenant_id = %s""",
            [payslip_id, scoped(session)])
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "No payslip with that id")

        cur.execute("SELECT * FROM hr_payroll_runs WHERE id = %s",
                    [row["payroll_run_id"]])
        run = cur.fetchone()
        company = _company_name(cur, row["tenant_id"])

    with db(session) as cur:
        A.audit(cur, session, "payslip.download", "hr_payslips", payslip_id,
                {"employee_code": row["employee_code"]}, ip=session.get("ip"))

    pdf = payslip_pdf(dict(row), dict(row), dict(run), company)
    name = f"payslip-{row['employee_code']}-{run['period_year']}-{run['period_month']:02d}.pdf"
    return _pdf(pdf, name)


@app.get("/api/payroll/runs/{run_id}/pdf")
def payroll_register_document(run_id: str,
                              session: dict = Depends(current_session)):
    require(session, "payroll.read")
    with db(session) as cur:
        cur.execute("SELECT * FROM hr_payroll_runs WHERE id = %s AND tenant_id = %s",
                    [run_id, scoped(session)])
        run = cur.fetchone()
        if not run:
            raise HTTPException(404, "No payroll run with that id")

        cur.execute(
            """SELECT p.*, e.employee_code, e.full_name
                 FROM hr_payslips p
                 JOIN hr_employees e ON e.id = p.employee_id
                WHERE p.payroll_run_id = %s
                ORDER BY e.employee_code""",
            [run_id])
        payslips = [dict(r) for r in cur.fetchall()]
        company = _company_name(cur, run["tenant_id"])

    if not payslips:
        raise HTTPException(409, "This run has no payslips yet. Compute it first.")

    pdf = payroll_register_pdf(dict(run), payslips, company)
    name = f"payroll-register-{run['period_year']}-{run['period_month']:02d}.pdf"
    return _pdf(pdf, name)


@app.get("/api/employees/{employee_id}/pdf")
def employee_document(employee_id: str, reveal_ids: bool = False,
                      session: dict = Depends(current_session)):
    require(session, "employee.read")
    if reveal_ids:
        require(session, "employee.id.reveal")
    data = get_employee(employee_id, reveal_ids=reveal_ids, session=session)
    with db(session) as cur:
        company = _company_name(cur, data["employee"]["tenant_id"])
    pdf = employee_profile_pdf(data, company)
    return _pdf(pdf, f"employee-{data['employee']['employee_code']}.pdf")
