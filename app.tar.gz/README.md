# Meridian ERP — install

One command on a fresh Ubuntu VPS. Installs PostgreSQL, applies the
schema, runs the API as a service that restarts itself, and serves the
web app.

    sudo bash install.sh

Safe to run again. Nothing here destroys existing data.

## What it sets up

- PostgreSQL with a database password generated on your server. It is
  written to /opt/meridian/.env, readable only by root, and is never in
  this repository — which is why the repository can be public without
  that being a credential leak.
- The API on port 8000, as a systemd service that survives a reboot.
- The web app on port 4173.
- Your company, the five standard roles, and one administrator.

The administrator password is printed once at the end. Write it down.

## Afterwards

    systemctl restart meridian-api      restart the API
    journalctl -u meridian-api -n 50    see what went wrong
    systemctl status meridian-api       is it running

## Before real staff data

The installer adds five sample employees so the directory is not empty.
Delete them before entering real people. Also still outstanding: HTTPS,
tightening CORS from `*` to your domain, and database backups.
