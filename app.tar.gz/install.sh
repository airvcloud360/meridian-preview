#!/usr/bin/env bash
#
# Meridian ERP — install on a fresh Ubuntu VPS
#
# Installs PostgreSQL, applies the schema, runs the API as a service that
# survives reboots, and serves the web app.
#
# Safe to run more than once. If something fails halfway, fix it and run
# again — nothing here destroys existing data.
#
#   bash install.sh
#
set -euo pipefail

APP_DIR=/opt/meridian
DB_NAME=meridian
DB_USER=meridian
API_PORT=8000
WEB_PORT=4173

say()  { printf "\n\033[1m%s\033[0m\n" "$*"; }
ok()   { printf "  \033[32mok\033[0m  %s\n" "$*"; }
warn() { printf "  \033[33m!!\033[0m  %s\n" "$*"; }

if [ "$(id -u)" -ne 0 ]; then
  echo "Run this as root:  sudo bash install.sh"; exit 1
fi

if [ ! -f "$(dirname "$0")/backend/01_hr_core.sql" ]; then
  echo "Run this from inside the unpacked meridian-app folder."; exit 1
fi
SRC="$(cd "$(dirname "$0")" && pwd)"

# ---------------------------------------------------------------------------
say "1/7  Installing PostgreSQL and Python"
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq
apt-get install -y -qq postgresql python3-venv python3-pip curl >/dev/null
systemctl enable --now postgresql >/dev/null 2>&1 || service postgresql start
sleep 2
ok "installed"

# ---------------------------------------------------------------------------
say "2/7  Creating the database"

# The password is generated here and never leaves this machine. It is not in
# the repository, which is why the repository can be public without that
# being a credential leak.
if [ -f "$APP_DIR/.env" ]; then
  DB_PASS="$(grep -oP 'password=\K[^ ]+' "$APP_DIR/.env")"
  ok "reusing the existing database password"
else
  DB_PASS="$(head -c 32 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 24)"
fi

sudo -u postgres psql -tAc "SELECT 1 FROM pg_roles WHERE rolname='$DB_USER'" | grep -q 1 || \
  sudo -u postgres psql -qc "CREATE ROLE $DB_USER LOGIN PASSWORD '$DB_PASS'"
sudo -u postgres psql -qc "ALTER ROLE $DB_USER PASSWORD '$DB_PASS'"

sudo -u postgres psql -tAc "SELECT 1 FROM pg_database WHERE datname='$DB_NAME'" | grep -q 1 || \
  sudo -u postgres createdb -O "$DB_USER" "$DB_NAME"
ok "database ready"

# ---------------------------------------------------------------------------
say "3/7  Applying the schema"
mkdir -p "$APP_DIR"
cp -r "$SRC/backend" "$SRC/app" "$APP_DIR/"
cp "$SRC/reset-password.sh" "$APP_DIR/reset-password.sh"

for f in 00_platform.sql 01_hr_core.sql 02_payroll_engine.sql 03_auth.sql 04_password_reset.sql; do
  # Each migration is written to be safe to re-run. Failing loudly here is
  # correct: a half-applied schema is worse than a stopped install.
  sudo -u postgres psql -q -v ON_ERROR_STOP=1 -d "$DB_NAME" -f "$APP_DIR/backend/$f" >/dev/null
  ok "$f"
done
sudo -u postgres psql -q -d "$DB_NAME" -c "GRANT ALL ON ALL TABLES IN SCHEMA public TO $DB_USER;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO $DB_USER;
GRANT ALL ON SCHEMA public TO $DB_USER;
GRANT USAGE ON SCHEMA app TO $DB_USER;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA app TO $DB_USER;" >/dev/null
ok "permissions granted"

# ---------------------------------------------------------------------------
say "4/7  Installing the API"
python3 -m venv "$APP_DIR/venv" 2>/dev/null || true
"$APP_DIR/venv/bin/pip" install -q --upgrade pip
"$APP_DIR/venv/bin/pip" install -q fastapi "uvicorn[standard]" psycopg2-binary \
    bcrypt reportlab python-multipart
ok "dependencies installed"

cat > "$APP_DIR/.env" <<EOF
MERIDIAN_DSN=host=127.0.0.1 dbname=$DB_NAME user=$DB_USER password=$DB_PASS
EOF
chmod 600 "$APP_DIR/.env"
ok "credentials written to $APP_DIR/.env (readable only by root)"

# ---------------------------------------------------------------------------
say "5/7  Running the API as a service"
cat > /etc/systemd/system/meridian-api.service <<EOF
[Unit]
Description=Meridian ERP API
After=network.target postgresql.service
Requires=postgresql.service

[Service]
Type=simple
WorkingDirectory=$APP_DIR/backend
EnvironmentFile=$APP_DIR/.env
ExecStart=$APP_DIR/venv/bin/uvicorn api:app --host 0.0.0.0 --port $API_PORT
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/meridian-web.service <<EOF
[Unit]
Description=Meridian ERP web app
After=network.target

[Service]
Type=simple
WorkingDirectory=$APP_DIR/app
ExecStart=/usr/bin/python3 -m http.server $WEB_PORT
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now meridian-api meridian-web >/dev/null 2>&1
sleep 4

if systemctl is-active --quiet meridian-api; then ok "API service running"
else warn "API did not start. Check:  journalctl -u meridian-api -n 40"; fi
if systemctl is-active --quiet meridian-web; then ok "web service running"; fi

# ---------------------------------------------------------------------------
say "6/7  Opening the ports"
if command -v ufw >/dev/null && ufw status | grep -q "Status: active"; then
  ufw allow "$API_PORT"/tcp >/dev/null 2>&1 || true
  ufw allow "$WEB_PORT"/tcp >/dev/null 2>&1 || true
  ok "firewall updated"
else
  ok "no active firewall to change"
fi

# ---------------------------------------------------------------------------
say "7/7  Creating your company and administrator"
ADMIN_PASS="$(head -c 24 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 14)"
export MERIDIAN_DSN="host=127.0.0.1 dbname=$DB_NAME user=$DB_USER password=$DB_PASS"
export MERIDIAN_ADMIN_PASS="$ADMIN_PASS"

cd "$APP_DIR/backend"
SEED_OUT="$("$APP_DIR/venv/bin/python" seed_live.py 2>&1)" || {
  warn "seeding failed:"; echo "$SEED_OUT"; exit 1; }
echo "$SEED_OUT" | sed 's/^/  /'

IP="$(curl -4 -s --max-time 8 ifconfig.me || hostname -I | awk '{print $1}')"

cat <<EOF

============================================================
  Meridian ERP is live.

  Open:      http://$IP:$WEB_PORT
  Sign in:   admin@meridian.local
  Password:  $ADMIN_PASS

  Write that password down now. It is not stored anywhere
  you can read it back, and you will be asked to change it.
============================================================

  Useful later:
    systemctl restart meridian-api     restart the API
    journalctl -u meridian-api -n 50   see what went wrong
    bash install.sh                    safe to run again

  Locked out of every account?
    sudo bash /opt/meridian/reset-password.sh admin@meridian.local

EOF
