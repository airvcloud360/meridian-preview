#!/usr/bin/env bash
#
# Meridian ERP — restore from a backup
#
#   sudo bash /opt/meridian/restore.sh                  list what is available
#   sudo bash /opt/meridian/restore.sh <file.dump>      restore that one
#
# Restoring is the part nobody rehearses, so this script is written to be
# used by someone who is having a bad day: it lists the options, says what
# it is about to destroy, and makes a safety copy first.
#
set -euo pipefail

BACKUP_DIR=/var/backups/meridian
DB_NAME=meridian

if [ "$(id -u)" -ne 0 ]; then
  echo "Run with sudo:  sudo bash restore.sh"; exit 1
fi

if [ $# -eq 0 ]; then
  echo ""
  echo "Backups available:"
  echo ""
  if ! ls "$BACKUP_DIR"/meridian_*.dump >/dev/null 2>&1; then
    echo "  none found in $BACKUP_DIR"
    echo "  Take one with:  sudo bash /opt/meridian/backup.sh"
    exit 1
  fi
  for f in "$BACKUP_DIR"/meridian_*.dump; do
    printf "  %-46s %s\n" "$(basename "$f")" "$(du -h "$f" | cut -f1)"
  done
  echo ""
  echo "To restore one:"
  echo "  sudo bash /opt/meridian/restore.sh $(basename "$(ls -t "$BACKUP_DIR"/meridian_*.dump | head -1)")"
  echo ""
  exit 0
fi

FILE="$1"
[ -f "$FILE" ] || FILE="$BACKUP_DIR/$1"
if [ ! -f "$FILE" ]; then
  echo "Cannot find $1"; exit 1
fi

if ! sudo -u postgres pg_restore --list "$FILE" >/dev/null 2>&1; then
  echo "That file is not a readable backup. Refusing to go further."; exit 1
fi

TAKEN="$(date -r "$FILE" '+%d %b %Y at %H:%M')"

cat <<EOF

  About to restore from:
    $(basename "$FILE")   (taken $TAKEN)

  This REPLACES everything currently in the database. Any employee,
  salary or payroll entered since that backup was taken will be gone.

EOF

read -r -p "  Type RESTORE to continue: " CONFIRM
if [ "$CONFIRM" != "RESTORE" ]; then
  echo "  Cancelled. Nothing was changed."; exit 0
fi

# A safety copy of the current state before overwriting it. If the restore
# turns out to be the wrong choice, there is still a way back — the worst
# outcome would be discovering mid-restore that the current data was the
# good data.
SAFETY="$BACKUP_DIR/before_restore_$(date +%Y-%m-%d_%H%M).dump"
echo ""
echo "  Saving the current database first..."
sudo -u postgres pg_dump -Fc -d "$DB_NAME" -f "$SAFETY"
chmod 600 "$SAFETY"
echo "  saved to $(basename "$SAFETY")"

echo "  Stopping the application..."
systemctl stop meridian-api >/dev/null 2>&1 || true

echo "  Restoring..."
sudo -u postgres pg_restore --clean --if-exists -d "$DB_NAME" "$FILE" 2>/dev/null || true

echo "  Starting the application..."
systemctl start meridian-api >/dev/null 2>&1 || true
sleep 3

EMP="$(sudo -u postgres psql -tAc 'SELECT COUNT(*) FROM hr_employees' -d "$DB_NAME" 2>/dev/null || echo '?')"
USR="$(sudo -u postgres psql -tAc 'SELECT COUNT(*) FROM users' -d "$DB_NAME" 2>/dev/null || echo '?')"

cat <<EOF

============================================================
  Restore complete.

    employees in the database:  $EMP
    user accounts:              $USR

  If this was a mistake, the database as it was is saved at:
    $(basename "$SAFETY")

============================================================

EOF
