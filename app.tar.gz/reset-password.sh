#!/usr/bin/env bash
#
# Meridian ERP — reset a password from the server
#
# For when the last administrator is locked out and there is nobody left
# to ask. Access to this machine is the final authority; there is nothing
# above it to appeal to, which is why this script exists and why it can
# only be run by root.
#
#   sudo bash /opt/meridian/reset-password.sh
#   sudo bash /opt/meridian/reset-password.sh someone@example.com
#
set -euo pipefail

APP_DIR=/opt/meridian
EMAIL="${1:-admin@meridian.local}"

if [ "$(id -u)" -ne 0 ]; then
  echo "Run with sudo:  sudo bash reset-password.sh"; exit 1
fi

if [ ! -f "$APP_DIR/.env" ]; then
  echo "Cannot find $APP_DIR/.env — is Meridian installed?"; exit 1
fi

# shellcheck disable=SC1090
export MERIDIAN_DSN="$(grep -oP '^MERIDIAN_DSN=\K.*' "$APP_DIR/.env")"

"$APP_DIR/venv/bin/python" - "$EMAIL" <<'PY'
import os, sys, secrets
sys.path.insert(0, "/opt/meridian/backend")
import psycopg2, psycopg2.extras
import auth as A

psycopg2.extras.register_uuid()
email = sys.argv[1].strip().lower()

conn = psycopg2.connect(os.environ["MERIDIAN_DSN"])
cur = conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor)

cur.execute("SELECT id, full_name, tenant_id FROM users WHERE lower(email)=%s",
            [email])
row = cur.fetchone()
if not row:
    print(f"\nNo account with the email {email}.\n")
    cur.execute("SELECT email FROM users ORDER BY email LIMIT 20")
    accounts = [r["email"] for r in cur.fetchall()]
    if accounts:
        print("Accounts on this server:")
        for a in accounts:
            print(f"  {a}")
        print("\nRun again with one of these, for example:")
        print(f"  sudo bash /opt/meridian/reset-password.sh {accounts[0]}\n")
    sys.exit(1)

alphabet = "abcdefghjkmnpqrstuvwxyzACDEFGHJKLMNPQRSTUVWXYZ23456789"
temp = "".join(secrets.choice(alphabet) for _ in range(12))

cur.execute("""UPDATE users
                  SET password_hash = %s, must_change_password = true,
                      failed_attempts = 0, locked_until = NULL, is_active = true
                WHERE id = %s""",
            [A.hash_password(temp), row["id"]])

# Anything signed in as this account is signed out. If the reset is
# happening because someone else got in, leaving their session alive
# would make the reset pointless.
cur.execute("UPDATE sessions SET revoked_at = now() "
            "WHERE user_id = %s AND revoked_at IS NULL", [row["id"]])

# Recorded like every other reset. A rescue that leaves no trace is how a
# back door stops looking like one.
cur.execute("""INSERT INTO audit_log
                 (tenant_id, user_id, action, object_type, object_id, detail)
               VALUES (%s, %s, 'password.server_reset', 'user', %s, %s)""",
            [row["tenant_id"], row["id"], str(row["id"]),
             psycopg2.extras.Json({"via": "server console", "email": email})])

conn.commit()

print(f"""
============================================================
  Password reset for {email}

  New password:  {temp}

  Sign in with this, then choose your own password.
  Everyone signed in as this account has been signed out.
============================================================
""")
PY
