#!/usr/bin/env bash
#
# Meridian ERP — database backup
#
# Run by a timer every night, and safe to run by hand at any time:
#
#   sudo bash /opt/meridian/backup.sh
#
# A backup nobody has restored is not a backup, it is a hope. This script
# verifies every dump it takes by reading it back, and refuses to keep one
# that does not open.
#
set -euo pipefail

APP_DIR=/opt/meridian
BACKUP_DIR=/var/backups/meridian
KEEP_DAYS=30
DB_NAME=meridian

if [ "$(id -u)" -ne 0 ]; then
  echo "Run with sudo:  sudo bash backup.sh"; exit 1
fi

# Owned by postgres, not root. A dump contains every salary and every
# password hash, so it must not be world readable — but it also has to be
# readable by the account that writes and verifies it. postgres can already
# read all of this data directly, so giving it the dumps exposes nothing
# new, while root-only would leave pg_dump and pg_restore locked out of
# their own backups.
mkdir -p "$BACKUP_DIR"
chown postgres:postgres "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

STAMP="$(date +%Y-%m-%d_%H%M)"
FILE="$BACKUP_DIR/meridian_$STAMP.dump"

# Custom format rather than plain SQL: it compresses, and pg_restore can
# read a single table out of it without replaying the whole file.
sudo -u postgres pg_dump -Fc -d "$DB_NAME" -f "$FILE"
chmod 600 "$FILE"

# Verify by reading the archive back. A dump that cannot be listed is
# corrupt, and finding that out during a restore is finding out too late.
if ! sudo -u postgres pg_restore --list "$FILE" >/dev/null 2>&1; then
  echo "BACKUP FAILED VERIFICATION — removing $FILE"
  rm -f "$FILE"
  exit 1
fi

TABLES="$(sudo -u postgres pg_restore --list "$FILE" | grep -c 'TABLE DATA' || true)"
SIZE="$(du -h "$FILE" | cut -f1)"

# A dump can be valid and still be empty. Checking that the tables we
# expect are actually in it catches a backup taken against the wrong
# database, which is otherwise silent.
if [ "$TABLES" -lt 10 ]; then
  echo "BACKUP LOOKS WRONG — only $TABLES tables with data. Keeping it, but check."
fi

# Also keep a copy of the settings file. Restoring the data without the
# database password leaves you with a working database and an app that
# cannot open it.
cp "$APP_DIR/.env" "$BACKUP_DIR/env_$STAMP.txt" 2>/dev/null || true
chown postgres:postgres "$BACKUP_DIR"/env_*.txt 2>/dev/null || true
chmod 600 "$BACKUP_DIR"/env_*.txt 2>/dev/null || true

find "$BACKUP_DIR" -name 'meridian_*.dump' -mtime "+$KEEP_DAYS" -delete
find "$BACKUP_DIR" -name 'env_*.txt'       -mtime "+$KEEP_DAYS" -delete

COUNT="$(find "$BACKUP_DIR" -name 'meridian_*.dump' | wc -l)"

echo "Backup complete."
echo "  file:    $FILE"
echo "  size:    $SIZE"
echo "  tables:  $TABLES with data"
echo "  kept:    $COUNT backups, $KEEP_DAYS days"
echo ""
echo "This backup is on the same machine as the database. That protects"
echo "against a mistaken DELETE, not against losing the server. Copy these"
echo "off the machine as well."
